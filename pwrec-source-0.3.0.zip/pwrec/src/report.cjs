const fs = require('node:fs');
const path = require('node:path');
const escape = value => String(value ?? '').replace(/[\\`*_{}\[\]<>#|]/g, '\\$&').replace(/\r?\n/g, ' ');
const block = value => { const text = String(value ?? ''); const fence = '`'.repeat(Math.max(3, ...(text.match(/`+/g) || []).map(s => s.length + 1))); return `${fence}text\n${text}\n${fence}`; };
function writeReport(directory, manifest, entries) {
  const lines = ['# Khảo sát RPA', '', `- URL: ${escape(manifest.url)}`, `- Trạng thái: ${escape(manifest.status)}`, `- Browser: ${escape(manifest.channel)} ${escape(manifest.browser)}`, `- Bắt đầu: ${escape(manifest.startedAt)}`, '', 'Locator/code dưới đây là dữ liệu khảo sát, chưa phải script tự động hóa đã được xác minh.', 'DOM được chụp tại checkpoint, không cam kết đúng thời điểm trước/sau thao tác.', 'Các lần nhập liên tiếp được gộp khi cùng ô và không ngắt quá 750 ms; journal actions.jsonl vẫn giữ event thô.', ''];
  for (const event of entries) {
    if (event.type === 'businessStep') { lines.push(`## ${event.businessStep.id}. ${escape(event.businessStep.title)}`, ''); continue; }
    if (event.type === 'note') { lines.push(`Ghi chú: ${escape(event.text)}`, ''); continue; }
    lines.push(`### Event ${event.step}: ${escape(event.action.name)} — ${escape(event.page)}`, '', `URL: ${escape(event.url)}`, '');
    if (event.action.selector) lines.push('Locator:', block(event.action.selector), '');
    if (event.code) lines.push('Code:', block(event.code), '');
    if (event.mergedEvents > 1) lines.push(`Đã gộp ${event.mergedEvents} event nhập liệu.`, '');
  }
  if (manifest.errors.length) lines.push('## Cảnh báo', '', ...manifest.errors.map(e => `- ${escape(e.stage)}: ${escape(e.message)}`), '');
  const file = path.join(directory, 'summary.md');
  fs.writeFileSync(file, lines.join('\n'));
  return file;
}
module.exports = { writeReport };
