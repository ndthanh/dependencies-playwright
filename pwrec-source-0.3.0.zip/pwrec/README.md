# pwrec

CLI khảo sát thao tác người dùng, dùng Playwright **1.63.0**. Mở trình duyệt, thao tác như bình thường, lưu locator và DOM checkpoint để xem lại trong Trace Viewer. Không chạy lại các click đã ghi.

## Chạy ngay

Trên máy đang dựng tool, lệnh `pwrec` đã được đăng ký bằng `npm link`:

```sh
pwrec --demo
pwrec "https://trang-web-can-khao-sat"
```

1. Trình duyệt mở ra. Đăng nhập và thực hiện luồng khảo sát.
2. Quay lại terminal, nhấn **Enter trống** hoặc **Ctrl+C** để lưu. Giữ trình duyệt mở cho đến khi lưu xong.
3. Terminal in đường dẫn trace và lệnh mở, ví dụ:

```sh
pwrec view "recordings/2026-10-01T12-00-00-000Z-abcdef/trace.zip"
```

`--demo` mở trang local với ô nhập liệu, checkbox, nút lưu, iframe, chuyển trang và mở tab mới. Nút lưu chỉ tăng bộ đếm trong bộ nhớ của demo.

## Chạy trên Windows bằng thư mục bin

Cần Node.js 20 trở lên (`node` và `npm` có trong PATH) và Google Chrome đã cài trên máy. Từ bản 0.2.1, ghi khảo sát mặc định dùng Chrome. Giải nén mã nguồn, ví dụ đặt dự án tại `C:\Tools\pwrec`. Cài dependency ngay trong dự án:

```powershell
cd C:\Tools\pwrec
npm ci --omit=dev
```

Launcher tìm JavaScript tương đối từ vị trí của chính file `.cmd` (`%~dp0`), không phụ thuộc thư mục đang đứng trong terminal. Có thể thêm thẳng thư mục `pwrec\windows-bin` vào PATH, hoặc copy **hai file** vào thư mục `bin` nằm cạnh thư mục dự án `pwrec`, theo cấu trúc:

```text
<thư mục bất kỳ>\
  bin\
    pwrec.cmd
    tv.cmd
  pwrec\
    bin\pwrec.cjs
    node_modules\
```

Ví dụ copy vào `C:\Tools\bin` khi dự án ở `C:\Tools\pwrec`:

```powershell
New-Item -ItemType Directory -Force C:\Tools\bin
Copy-Item .\windows-bin\pwrec.cmd, .\windows-bin\tv.cmd C:\Tools\bin\
```

Không cần sửa đường dẫn trong `.cmd` với hai cấu trúc trên. Có thể di chuyển cả bộ sang ổ đĩa/thư mục khác mà vẫn chạy được; chỉ cập nhật PATH. Nếu thư mục bin riêng nằm ở vị trí khác, sửa `PWREC_ENTRY` thành đường dẫn tương đối bắt đầu bằng `%~dp0` tới `pwrec.cjs` và bỏ dòng fallback bên dưới.

Thêm `C:\Tools\bin` vào **User PATH** trong Environment Variables của Windows rồi mở terminal mới. Nếu thư mục bin của anh đã có trong PATH thì không cần thêm. Để thử ngay trong phiên PowerShell hiện tại:

```powershell
$env:Path = "C:\Tools\bin;$env:Path"
pwrec --version
pwrec "https://trang-web-can-khao-sat"
pwrec install # Tải Chromium cho Trace Viewer; chỉ cần làm lần đầu
pwrec view "C:\Survey recordings\session\trace.zip"
tv "C:\Survey recordings\session\trace.zip"
```

`pwrec.cmd` gọi trực tiếp `node` và file JavaScript của dự án, không cần `npm install -g` hay `npm link`. `tv.cmd` gọi `pwrec.cmd view` ở cùng thư mục bin. Cả hai chuyển tiếp tham số và mã thoát của CLI. Launcher không đổi thư mục làm việc: trace mặc định nằm trong `recordings` ở thư mục đang gọi lệnh; dùng `--output "D:\Survey recordings"` để chọn nơi lưu khác.

Ghi khảo sát bằng Chrome không cần tải Chromium. Nếu muốn dùng Edge đã cài:

```powershell
pwrec "https://trang-web-can-khao-sat" --channel msedge
```

`--channel chrome` là mặc định. Muốn ghi bằng Chromium của Playwright, chạy `pwrec install` rồi thêm `--channel chromium`. Lệnh `pwrec view` / `tv` vẫn dùng Trace Viewer của Playwright, tách biệt với channel ghi khảo sát. Tool tạo phiên trình duyệt riêng, không dùng profile cá nhân đang mở. Chưa chạy trực tiếp trên Windows hoặc Edge.

## Cài từ mã nguồn

```sh
cd pwrec
npm ci
npx playwright install chromium
npm test
npm link
pwrec --demo
```

Không cần cài global để chạy:

```sh
node bin/pwrec.cjs "https://trang-web-can-khao-sat"
```

## Đặt tên bước ngay lúc khảo sát

Trong terminal đang chạy `pwrec`, gõ lệnh rồi nhấn Enter:

```text
step Nhập hồ sơ
note Tên phải khớp giấy tờ khách hàng
```

Quay lại Chrome và thao tác. Khi chuyển sang nghiệp vụ tiếp theo, quay lại terminal:

```text
step Duyệt yêu cầu
note Chỉ trưởng nhóm được duyệt
```

Tên bước áp dụng cho các event nhận được tiếp theo, không đổi tên các thao tác đã ghi. Trace Viewer có marker `STEP`/`NOTE`; mỗi group thao tác và dòng Console có tên bước tương ứng. `note` gắn với bước hiện tại, hoặc là ghi chú chung nếu chưa đặt bước. Chờ thao tác trước hoàn tất rồi nhập lệnh vì recorder có thể buffer click khoảng 500 ms. Nên đặt tên trước khi bắt đầu một nghiệp vụ.

`help` hiện nhắc lệnh. Lệnh không hợp lệ chỉ báo lỗi, không kết thúc phiên. **Enter trên dòng trống** hoặc **Ctrl+C** mới lưu và dừng. Lệnh nhập ở terminal, không gõ vào form của website. Tool không chèn toolbar vào website; cần chuyển giữa terminal và Chrome để đặt tên.

## Tóm tắt và gộp nhập liệu

Khi lưu, tool tạo `summary.md` cạnh trace, gồm bước nghiệp vụ, ghi chú, page/URL, selector và code của thao tác. Có cả báo cáo cho phiên `partial`, kèm cảnh báo; DOM thiếu không được coi là đã ghi thành công.

Các event `fill` liên tiếp cùng page, locator và bước được gộp cho checkpoint/Console/Markdown. Khoảng nghỉ 750 ms, chuyển thao tác hoặc đổi bước/ghi chú sẽ chốt nhóm. Dừng phiên cũng chốt phần đang nhập. Gõ tiếp sau khoảng nghỉ tạo checkpoint mới; đây không phải gộp toàn bộ lịch sử của một ô. Không chạy lại fill vào website. `actions.jsonl` giữ nguyên event thô; số event trong journal có thể lớn hơn số checkpoint. DOM là trạng thái lúc checkpoint chạy sau gộp.

## Kiểm tra máy với doctor

```powershell
pwrec doctor
pwrec doctor --channel msedge --output "D:\recordings"
```

Kiểm tra Node.js, phiên bản Playwright, khả năng tạo/ghi thư mục output và khả năng mở browser được chọn. Doctor mở browser headless rồi đóng, không truy cập website nghiệp vụ; có thể tạo thư mục output nếu chưa tồn tại, file thử được xóa sau kiểm tra. Mã thoát 0 khi kiểm tra thành công, 1 khi có lỗi. Không tự cài đặt hay nâng cấp phần mềm. Chromium cho Trace Viewer được báo riêng, không quyết định khả năng ghi bằng Chrome.

## Tham số

```text
pwrec <url>                     URL đầy đủ http:// hoặc https://
pwrec --demo                    Trang thử nghiệm local
--output <directory>            Thư mục cha chứa các phiên, mặc định ./recordings
--channel chrome|msedge|chromium Chọn browser; mặc định Chrome đã cài trên máy
--headless                      Dành cho kiểm thử tự động
--no-filmstrip                  Tắt dải hình screencast của Trace Viewer
pwrec view <path>               Mở trace.zip hoặc thư mục raw
tv <path>                       Lệnh tắt trên Windows khi dùng windows-bin/tv.cmd
pwrec doctor                    Kiểm tra cài đặt; hỗ trợ --channel, --output
pwrec install                   Tải Chromium tương ứng
pwrec --help
pwrec --version
```

Mỗi lần chạy tạo thư mục phiên mới, không ghi đè phiên trước:

```text
recordings/<timestamp-random>/
  trace.zip       Trace hoàn chỉnh khi dừng bằng Enter/Ctrl+C
  actions.jsonl   Thao tác, code/selector, timestamp và lỗi checkpoint
  session.json    Browser, trạng thái phiên và thống kê
  summary.md      Bước nghiệp vụ, ghi chú và thao tác đã gộp
  raw/            Trace ghi trực tiếp xuống đĩa
```

Nếu đóng trình duyệt trước khi lưu, tool báo `partial`, giữ raw trace và journal; thử `pwrec view "<session>/raw"`. Đây là phục hồi tốt nhất có thể, không bảo đảm còn toàn bộ event cuối khi browser/process bị đóng đột ngột. Nếu lưu bị treo quá 15 giây, tool giữ dữ liệu raw và thoát với trạng thái partial.

## Xem lại

- Danh sách Actions: group chứa số thứ tự, page và code do recorder sinh, ví dụ `page.getByRole('button', ...).click()`.
- Chọn action `Evaluate` trong group: Call → Parameters / Return value chứa action, selector, code và ghi chú.
- Khung DOM: snapshot của trang lúc checkpoint chạy, có thể inspect trong viewer.
- Dải hình phía trên: screencast được bật mặc định (`screenshots: true` trong tracing). Đây là filmstrip của Trace Viewer, không phải file video MP4 hay lời gọi `page.screenshot()` cho từng bước.
- Tab Console: mỗi checkpoint ghi một dòng `[pwrec]` gồm step, page, action, locator, code, URL và tab gốc nếu có. Log phát trong chính Evaluate của step; chọn step hoặc giới hạn thời gian để lọc.
- Tab mới: có step `New tab page2 from page1` với DOM của tab mới sau DOMContentLoaded, kể cả chưa tương tác. Thao tác mở popup vẫn được giữ trên tab gốc. Recorder có thể buffer click khoảng 500ms nên step tải tab mới có thể xuất hiện trước step click tương ứng.
- Không có click highlight tự động. DOM này không cam kết before/after chính xác của gesture.
- Các lần gõ được gộp theo quy tắc 750 ms ở trên; tên bước nghiệp vụ do người khảo sát đặt qua terminal.

Trace, summary và journal lưu cục bộ, có thể chứa nội dung form, thông tin đăng nhập và dữ liệu trang/network của phiên khảo sát; tool không tự upload chúng.

## Cách ghi

Tool dùng bridge private `_enableRecorder({ recorderMode: 'api' })` của Playwright 1.63.0 để nhận actionAdded/actionUpdated/signalAdded. Các callback đưa metadata vào hàng đợi; sau khi gộp fill, mỗi item mở group rồi gọi `page.evaluate()` để log metadata qua console.log và trả metadata về, đồng thời Playwright tạo DOM checkpoint. Không resolve lại locator và không replay click/fill. Dialog của trang được để người dùng xử lý trực tiếp.

Các action vẫn được ghi vào journal nếu DOM checkpoint gặp lỗi do navigation hoặc tab đóng. Dùng chính xác phiên bản đã pin; thay Playwright cần chạy lại test vì recorder bridge không phải public API.

## Kiểm thử

`npm test` mở fixture local và phát input qua CDP để tách gesture người dùng mô phỏng khỏi API locator.click. Kiểm tra nhập liệu, checkbox, nút biến mất, iframe, popup chưa có tương tác, navigation, số POST, locator trong trace, DOM snapshot, filmstrip bật/tắt, console log nằm trong step, shutdown CLI và phục hồi raw trace. `node scripts/check-viewer.cjs` kiểm tra bản render trong Trace Viewer sau npm test (chỉ có trong gói mã nguồn). Các test bổ sung kiểm tra STEP/NOTE, gộp fill và chốt lúc dừng/đổi bước, summary cho cả phiên partial, lệnh terminal không hợp lệ, doctor với thư mục lỗi và khi thiếu dependency. Chạy thêm `node scripts/check-viewer.cjs --features` để xác minh tên bước, ghi chú, DOM và Console trong Trace Viewer. Test không truy cập hệ thống nghiệp vụ thật.

Các tính năng 0.2.0 chỉ có trong phiên ghi mới. Trace 0.1.0 đã lưu không thể bổ sung hình screencast hoặc DOM tab mới bị thiếu từ quá khứ.
