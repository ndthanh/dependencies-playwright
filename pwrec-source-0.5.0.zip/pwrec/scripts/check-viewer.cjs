const { chromium } = require('playwright');
const fs = require('node:fs');
const http = require('node:http');
const path = require('node:path');
const assert = require('node:assert/strict');

(async () => {
  const downloads = process.argv.includes('--downloads');
  const toolbar = process.argv.includes('--toolbar');
  const features = process.argv.includes('--features');
  const latest = JSON.parse(fs.readFileSync(downloads ? 'test-results/downloads-latest.json' : toolbar ? 'test-results/toolbar-latest.json' : features ? 'test-results/features-latest.json' : 'test-results/latest.json', 'utf8'));
  const root = path.join(path.dirname(require.resolve('playwright-core/package.json')), 'lib/vite/traceViewer');
  const server = http.createServer((req, res) => {
    const pathname = new URL(req.url, 'http://localhost').pathname;
    const file = pathname === '/sample.zip' ? latest.trace : path.join(root, pathname === '/' ? 'index.html' : pathname);
    if (file !== latest.trace && !file.startsWith(root + path.sep)) { res.writeHead(403).end(); return; }
    const mime = { '.js': 'application/javascript', '.html': 'text/html', '.css': 'text/css', '.zip': 'application/zip', '.svg': 'image/svg+xml', '.wasm': 'application/wasm' };
    try { res.setHeader('Content-Type', mime[path.extname(file)] || 'application/octet-stream'); res.end(fs.readFileSync(file)); }
    catch { res.writeHead(404).end(); }
  });
  await new Promise(r => server.listen(0, '127.0.0.1', r));
  const browser = await chromium.launch();
  try {
    const page = await browser.newPage({ viewport: { width: 1600, height: 1000 } });
    page.setDefaultTimeout(10000);
    await page.goto(`http://127.0.0.1:${server.address().port}/?trace=/sample.zip`);
    const group = page.getByRole('treeitem', { name: downloads ? /DOWNLOAD 001 Renamed:/ : toolbar ? /SNAPSHOT:/ : features ? /\[1: Nhập hồ sơ\].*fill/ : /New tab page2 from page1/ });
    await group.waitFor();
    if (features) {
      await page.getByRole('treeitem', { name: /STEP 1: Nhập hồ sơ/ }).waitFor();
      await page.getByRole('treeitem', { name: /NOTE: Tên theo giấy tờ/ }).waitFor();
    }
    await group.click();
    await group.press('ArrowRight');
    await group.getByRole('treeitem', { name: /^Evaluate/ }).click();
    await page.getByText('Console', { exact: true }).click();
    await page.getByText(downloads ? /\[pwrec\].*downloadRenamed.*sha256/ : toolbar ? /\[pwrec\].*manualSnapshot/ : features ? /\[pwrec\].*Nhập hồ sơ.*fill/ : /\[pwrec\].*pageOpened/).first().waitFor();
    let rendered = false;
    for (let attempt = 0; attempt < 40 && !rendered; attempt++) {
      for (const frame of page.frames().slice(1)) {
        const text = await frame.locator('body').innerText().catch(() => '');
        if (downloads ? text.includes('Thử pwrec') : toolbar ? text.includes('Thử pwrec') && !text.includes('Đã lưu 1 lần') && await frame.getByRole('textbox', { name: 'Họ tên' }).inputValue().catch(() => '') === 'Nguyễn Văn An' : features ? text.includes('Thử pwrec') && await frame.getByRole('textbox', { name: 'Họ tên' }).inputValue().catch(() => '') === 'Anh' : text.includes('Next page') && text.includes('Back')) rendered = true;
      }
      if (!rendered) await new Promise(r => setTimeout(r, 100));
    }
    assert(rendered, 'Expected checkpoint DOM must render');
    await page.screenshot({ path: downloads ? 'test-results/viewer-downloads-0.5.0.png' : toolbar ? 'test-results/viewer-0.4.0.png' : features ? 'test-results/viewer-0.3.0.png' : 'test-results/viewer-popup.png' });
    fs.writeFileSync('test-results/viewer-dom.html', await page.content());
    console.log(downloads ? 'PASS: download rename result and SHA-256 visible in Trace Viewer' : toolbar ? 'PASS: manual snapshot shows legacy-page DOM before save, with Unicode input' : features ? 'PASS: named step, note, merged fill DOM and Console visible in Trace Viewer' : 'PASS: popup DOM and matching Console note visible in Trace Viewer');
  } finally { await browser.close(); await new Promise(r => server.close(r)); }
})().catch(e => { console.error(e); process.exit(1); });
