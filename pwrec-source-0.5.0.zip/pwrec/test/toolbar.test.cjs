const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { unzipSync, strFromU8 } = require('fflate');
const { startSession } = require('../src/session.cjs');
const { startDemo } = require('../src/demo.cjs');
const delay = ms => new Promise(r => setTimeout(r, ms));
async function eventually(fn) { for (let i = 0; i < 100; i++) { if (await fn()) return; await delay(50); } throw Error('Condition not reached'); }
const records = s => fs.readFileSync(path.join(s.directory, 'actions.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);
function trace(file) { const zip = unzipSync(fs.readFileSync(file)); return strFromU8(zip[Object.keys(zip).find(k => k.endsWith('.trace'))]).trim().split('\n').map(JSON.parse); }
async function click(cdp, selector, toolbar = false) {
  const expression = `(()=>{const el=${toolbar ? "window.__pwrecNativeOverlay.tools.querySelector('[data-pwrec-toolbar]').shadowRoot" : 'document'}.querySelector(${JSON.stringify(selector)});el.scrollIntoView({block:'center',behavior:'instant'});const r=el.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2}})()`;
  const { result } = await cdp.send('Runtime.evaluate', { expression, returnByValue: true });
  for (const type of ['mouseMoved','mousePressed','mouseReleased']) await cdp.send('Input.dispatchMouseEvent', { type, ...result.value, button: 'left', clickCount: 1 });
}

test('toolbar Unicode annotations and manual DOM snapshot tolerate legacy Array.find', { timeout: 25000 }, async () => {
  const demo = await startDemo(); let session;
  try {
    session = await startSession({ url: demo.url + '/legacy', headless: true, output: fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-toolbar-')), onStatus: () => {} });
    const errors = []; session.page.on('pageerror', e => errors.push(e.message));
    const cdp = await session.context.newCDPSession(session.page);
    await session.page.waitForFunction(() => !!window.__pwrecNativeOverlay?.tools.querySelector('[data-pwrec-toolbar]'));
    await click(cdp, '#note', true);
    await click(cdp, '#save', true);
    await session.page.waitForFunction(() => window.__pwrecNativeOverlay.tools.querySelector('[data-pwrec-toolbar]').shadowRoot.getElementById('error').textContent.includes('Anh nhập'));
    await click(cdp, '#cancel', true);
    for (const [kind, text] of [['step','Duyệt hồ sơ tiếng Việt'], ['note','Kiểm tra số tài khoản trước khi lưu']]) {
      await click(cdp, '#' + kind, true);
      await cdp.send('Input.insertText', { text });
      await click(cdp, '#save', true);
      await session.page.waitForFunction(() => !window.__pwrecNativeOverlay.tools.querySelector('[data-pwrec-toolbar]').shadowRoot.querySelector('dialog').open);
    }
    await click(cdp, '#name');
    await cdp.send('Input.insertText', { text: 'Nguyễn Văn An' });
    await click(cdp, '#snapshot', true);
    await session.page.waitForFunction(() => window.__pwrecNativeOverlay.tools.querySelector('[data-pwrec-toolbar]').shadowRoot.getElementById('status').textContent === 'Đã lưu snapshot ✓');
    assert.equal(demo.getWrites(), 0);
    assert.equal(await session.page.evaluate(() => [].find('abc')), 'legacy:abc');
    await session.page.screenshot({ path: path.join(__dirname, '../test-results/toolbar-0.4.0.png') });
    await click(cdp, '#save');
    await eventually(() => demo.getWrites() === 1);
    const result = await session.stop('toolbar regression');
    assert.equal(result.status, 'saved'); assert.deepEqual(errors, []);
    const journal = records(session);
    assert(journal.some(e => e.action?.text === 'Nguyễn Văn An'));
    assert(journal.some(e => e.businessStep?.title === 'Duyệt hồ sơ tiếng Việt'));
    assert(journal.some(e => e.type === 'note' && e.text.startsWith('Kiểm tra')));
    assert(!journal.some(e => e.action?.selector?.includes('data-pwrec-toolbar') || e.action?.text === 'Duyệt hồ sơ tiếng Việt'));
    const events = trace(result.trace);
    const group = events.find(e => e.type === 'before' && e.title?.includes('SNAPSHOT:')); assert(group);
    const evaluation = events.find(e => e.type === 'before' && e.parentId === group.callId && e.method === 'evaluateExpression');
    const snapshots = events.filter(e => e.type === 'frame-snapshot' && e.snapshot.callId === evaluation.callId);
    assert(snapshots.length > 0); assert(JSON.stringify(events).includes('Nguyễn Văn An'));
    assert(!JSON.stringify(snapshots).includes('Đã lưu 1 lần'));
    assert.equal(demo.getWrites(), 1);
    fs.writeFileSync(path.join(__dirname, '../test-results/toolbar-latest.json'), JSON.stringify(result, null, 2));
  } finally { if (session) await session.stop('cleanup'); await demo.close(); }
});

test('popup windows and tabs each emit one close marker without evaluating closed DOM', { timeout: 25000 }, async () => {
  const demo = await startDemo(); let session;
  try {
    session = await startSession({ url: demo.url, headless: true, output: fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-lifecycle-')), onStatus: () => {} });
    const cdp = await session.context.newCDPSession(session.page);
    for (const selector of ['#popup', 'a[target]']) {
      await click(cdp, selector);
      await eventually(() => session.context.pages().length === 2);
      const popup = session.context.pages()[1];
      await popup.waitForLoadState('domcontentloaded');
      await eventually(() => records(session).filter(e => e.type === 'pageOpened').length === (selector === '#popup' ? 1 : 2));
      popup.setDefaultTimeout(5000);
      await popup.waitForFunction(() => !!window.__pwrecNativeOverlay?.tools.querySelector('[data-pwrec-toolbar]'));
      const popupCDP = await session.context.newCDPSession(popup);
      await click(popupCDP, '#snapshot', true);
      await popup.waitForFunction(() => window.__pwrecNativeOverlay.tools.querySelector('[data-pwrec-toolbar]').shadowRoot.getElementById('status').textContent === 'Đã lưu snapshot ✓');
      await popup.goto(demo.url + '/');
      popup.setDefaultTimeout(5000);
      await popup.waitForFunction(() => !!window.__pwrecNativeOverlay?.tools.querySelector('[data-pwrec-toolbar]'));
      await session.flush();
      await popup.close(); await session.flush();
    }
    const result = await session.stop('lifecycle regression');
    const closed = records(session).filter(e => e.type === 'pageClosed');
    assert.equal(closed.length, 2); assert(closed.every(e => e.action.opener === 'page1'));
    assert.notEqual(closed[0].page, closed[1].page);
    const events = trace(result.trace);
    for (const event of closed) {
      const group = events.find(e => e.type === 'before' && e.title?.includes(`Closed page ${event.page}:`)); assert(group);
      assert(!events.some(e => e.parentId === group.callId && e.method === 'evaluateExpression'));
    }
    assert(fs.readFileSync(result.summary, 'utf8').includes('pageClosed'));
    assert(!result.errors.some(e => e.message.includes('Page closed before DOM checkpoint')));
  } finally { if (session) await session.stop('cleanup'); await demo.close(); }
});
