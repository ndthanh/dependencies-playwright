const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { startSession } = require('../src/session.cjs');
const { startDemo } = require('../src/demo.cjs');
const { unzipSync, strFromU8 } = require('fflate');
const delay = ms => new Promise(r => setTimeout(r, ms));
async function eventually(fn) { for (let i=0; i<200; i++) { if (await fn()) return; await delay(50); } throw Error('Condition not reached'); }
async function click(cdp, expression) {
  const { result } = await cdp.send('Runtime.evaluate', { expression: `(()=>{const el=${expression};el.scrollIntoView({block:'center',behavior:'instant'});const r=el.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2}})()`, returnByValue:true });
  for(const type of ['mouseMoved','mousePressed','mouseReleased']) await cdp.send('Input.dispatchMouseEvent',{type,...result.value,button:'left',clickCount:1});
}
const ui = "window.__pwrecNativeOverlay.tools.querySelector('[data-pwrec-toolbar]').shadowRoot";

test('native codegen controls remain functional; downloads retained, linked, renamed via UI, failures captured', {timeout:30000}, async()=>{
  const demo=await startDemo();let s;
  try{
    s=await startSession({url:demo.url,headless:true,output:fs.mkdtempSync(path.join(os.tmpdir(),'pwrec-downloads-')),onStatus:()=>{}});
    await s.page.waitForFunction(()=>!!window.__pwrecNativeOverlay?.tools.querySelector('[data-pwrec-toolbar]'));
    const cdp=await s.context.newCDPSession(s.page);
    assert.equal(await s.page.evaluate(()=>window.__pwrecNativeOverlay.tools.querySelectorAll('x-pw-tool-item').length),6);
    // Toggle the original Playwright recording control off and on.
    await click(cdp,"window.__pwrecNativeOverlay.tools.querySelector('.record')");
    await s.page.waitForFunction(()=>!window.__pwrecNativeOverlay.tools.querySelector('.record').classList.contains('toggled'));
    await click(cdp,"window.__pwrecNativeOverlay.tools.querySelector('.record')");
    await s.page.waitForFunction(()=>window.__pwrecNativeOverlay.tools.querySelector('.record').classList.contains('toggled'));
    await s.setStep('Xuất báo cáo');
    for(let i=1;i<=2;i++){
      await click(cdp,"document.querySelector('#download')");
      await eventually(()=>s.downloads.list().filter(d=>d.status==='completed').length===i);
      await delay(650); // let codegen correlate each independent click
    }
    assert.equal(demo.getDownloads(),2,'no request replay');
    const before=s.downloads.list();
    assert.equal(before[0].suggestedFilename,'report.csv');
    assert.notEqual(before[0].relativePath,before[1].relativePath);
    assert(before.every(d=>d.trigger?.code.includes("waitForEvent('download')")));
    await assert.rejects(s.downloads.rename('001','../outside.csv'));
    fs.writeFileSync(path.join(s.directory,'downloads/001/existing.csv'),'keep me');
    await assert.rejects(s.downloads.rename('001','existing.csv'));
    assert.equal(fs.readFileSync(path.join(s.directory,'downloads/001/existing.csv'),'utf8'),'keep me');
    await click(cdp,`${ui}.getElementById('downloads')`);
    await s.page.waitForFunction(()=>window.__pwrecNativeOverlay.tools.querySelector('[data-pwrec-toolbar]').shadowRoot.querySelector('dialog').open);
    await click(cdp,`${ui}.getElementById('text')`);
    // Select text using the native DOM selection; input itself is sent through CDP.
    await cdp.send('Runtime.evaluate',{expression:`${ui}.getElementById('text').select()`});
    await cdp.send('Input.insertText',{text:'Báo cáo cuối ngày.csv'});
    await click(cdp,`${ui}.getElementById('save')`);
    await eventually(()=>s.downloads.list()[0].filename==='Báo cáo cuối ngày.csv');
    await s.page.waitForFunction(()=>!window.__pwrecNativeOverlay.tools.querySelector('[data-pwrec-toolbar]').shadowRoot.querySelector('dialog').open);
    await click(cdp,"document.querySelector('#download-fail')");
    await eventually(()=>s.downloads.list().some(d=>d.status==='failed'));
    await s.downloads.drain();await s.flush();
    await click(cdp,`${ui}.getElementById('downloads')`);
    await s.page.waitForFunction(()=>window.__pwrecNativeOverlay.tools.querySelector('[data-pwrec-toolbar]').shadowRoot.querySelector('dialog').open);
    await s.page.screenshot({path:path.join(__dirname,'../test-results/downloads-0.5.0.png')});
    await click(cdp,`${ui}.getElementById('cancel')`);
    const result=await s.stop('downloads regression');
    assert.equal(result.status,'saved');
    const items=JSON.parse(fs.readFileSync(path.join(s.directory,'downloads.json'),'utf8'));
    for(const item of items.filter(d=>d.status==='completed')){
      const data=fs.readFileSync(path.join(s.directory,item.relativePath));
      assert.equal(data.length,item.bytes);assert.equal(crypto.createHash('sha256').update(data).digest('hex'),item.sha256);
      assert.equal(item.businessStep.title,'Xuất báo cáo');
    }
    assert(!fs.existsSync(path.join(s.directory,'downloads/001/report.csv')));
    const summary=fs.readFileSync(result.summary,'utf8');assert(summary.includes('Báo cáo cuối ngày.csv'));assert(summary.includes('SHA-256'));assert(summary.includes('failed'));
    assert(summary.includes('download1.saveAs'));
    const zip=unzipSync(fs.readFileSync(result.trace));const text=strFromU8(zip[Object.keys(zip).find(k=>k.endsWith('.trace'))]);
    for(const kind of ['downloadCompleted','downloadFailed','downloadRenamed']) assert(text.includes(kind));
    fs.writeFileSync(path.join(__dirname,'../test-results/downloads-latest.json'),JSON.stringify(result,null,2));
  }finally{if(s)await s.stop();await demo.close();}
});

test('unfinished download is cancelled with an explicit outcome when finishing', {timeout:15000}, async()=>{
 const demo=await startDemo();let s;
 try{
  s=await startSession({url:demo.url,headless:true,output:fs.mkdtempSync(path.join(os.tmpdir(),'pwrec-download-stop-')),onStatus:()=>{}});
  const pending=s.page.waitForEvent('download');
  await s.page.evaluate(()=>{location.href='/download-slow'});await pending;
  await eventually(()=>s.downloads.list().length===1);
  await s.downloads.finish(30);
  const result=await s.stop();
  assert.equal(result.downloads[0].status,'failed');assert(result.downloads[0].cancelReason.includes('stopped'));
 }finally{if(s)await s.stop();await demo.close();}
});
