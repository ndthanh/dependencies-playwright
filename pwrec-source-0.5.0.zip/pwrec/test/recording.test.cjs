const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { spawn, spawnSync } = require('node:child_process');
const { unzipSync, strFromU8 } = require('fflate');
const { startSession } = require('../src/session.cjs');
const { startDemo } = require('../src/demo.cjs');

const delay = ms => new Promise(r => setTimeout(r, ms));
async function eventually(fn) {
  for (let i = 0; i < 100; i++) { if (await fn()) return; await delay(50); }
  throw new Error('Condition not reached');
}
const readEvents = session => fs.readFileSync(path.join(session.directory, 'actions.jsonl'), 'utf8').trim().split('\n').filter(Boolean).map(JSON.parse);
function traceEvents(file) {
  const zip = unzipSync(fs.readFileSync(file));
  const key = Object.keys(zip).find(key => key.endsWith('.trace'));
  return strFromU8(zip[key]).trim().split('\n').map(JSON.parse);
}
async function nativeClick(cdp, selector) {
  const { result } = await cdp.send('Runtime.evaluate', {
    expression: `(()=>{const el=document.querySelector(${JSON.stringify(selector)});el.scrollIntoView({block:"center",behavior:"instant"});const r=el.getBoundingClientRect();return {x:r.x+r.width/2,y:r.y+r.height/2}})()`, returnByValue: true,
  });
  for (const type of ['mouseMoved', 'mousePressed', 'mouseReleased'])
    await cdp.send('Input.dispatchMouseEvent', { type, ...result.value, button: 'left', clickCount: 1 });
}

test('native gestures: fill, checkbox, removed target, save, iframe, popup and navigation', { timeout: 45000 }, async () => {
  const output = fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-integration-'));
  const demo = await startDemo();
  let session;
  try {
    session = await startSession({ url: demo.url, output, headless: true, onStatus: () => {} });
    const cdp = await session.context.newCDPSession(session.page);
    await delay(1200);
    await nativeClick(cdp, '#name');
    await cdp.send('Input.insertText', { text: 'Test user' });
    await nativeClick(cdp, '#agree');
    await nativeClick(cdp, '#remove');
    await nativeClick(cdp, '#save');
    await eventually(() => demo.getWrites() === 1);
    await eventually(() => readEvents(session).some(e => e.action?.selector?.includes('Lưu một lần')));
    // Click inside the iframe with real input, using top-frame coordinates.
    const { result: frameBox } = await cdp.send('Runtime.evaluate', { expression: '(()=>{const f=document.querySelector("iframe");f.scrollIntoView({block:"center",behavior:"instant"});const a=f.getBoundingClientRect();const b=f.contentDocument.querySelector("button").getBoundingClientRect();return {x:a.x+b.x+b.width/2+1,y:a.y+b.y+b.height/2+1}})()', returnByValue: true });
    for (const type of ['mouseMoved', 'mousePressed', 'mouseReleased'])
      await cdp.send('Input.dispatchMouseEvent', { type, ...frameBox.value, button: 'left', clickCount: 1 });
    await eventually(() => readEvents(session).some(e => e.action?.selector?.includes('Inside frame')));
    await nativeClick(cdp, 'a[target]');
    await eventually(() => session.context.pages().length === 2);
    const popup = session.context.pages()[1];
    await delay(1200);
    const popupCDP = await session.context.newCDPSession(popup);
    await nativeClick(popupCDP, 'a');
    await eventually(() => popup.url() === demo.url + '/');
    await nativeClick(cdp, 'a:not([target])');
    await eventually(() => session.page.url().endsWith('/next'));
    await delay(700);
    const result = await session.stop('test');
    assert(result.trace);
    const records = readEvents(session);
    assert(records.some(e => e.action?.name === 'fill' && e.action.text === 'Test user'));
    assert(records.some(e => e.action?.name === 'check'));
    assert(records.some(e => e.action?.selector?.includes('Bấm rồi biến mất')));
    assert(records.some(e => e.action?.selector?.includes('Inside frame')));
    assert(new Set(records.filter(e => e.page).map(e => e.page)).size >= 2);
    assert.equal(demo.getWrites(), 1);
    const events = traceEvents(result.trace);
    const evals = events.filter(e => e.type === 'before' && e.method === 'evaluateExpression');
    assert(evals.length >= 6);
    for (const e of evals) assert(e.parentId, 'Every checkpoint belongs to a group');
    assert(events.some(e => e.type === 'frame-snapshot'));
    assert.equal(events.filter(e => e.type === 'screenshot').length, 0);
    assert(events.some(e => e.type === 'screencast-frame'), 'Filmstrip enabled by default');
    const logs = events.filter(e => e.type === 'console' && e.text?.startsWith('[pwrec] '));
    assert(logs.some(e => e.text.includes('Bấm rồi biến mất')));
    for (const e of evals) {
      const after = events.find(a => a.type === 'after' && a.callId === e.callId);
      assert(logs.some(log => log.time >= e.startTime && log.time <= after.endTime), 'Console note occurs within its checkpoint');
    }
    assert(JSON.stringify(events).includes('Bấm rồi biến mất'));
    assert.equal(await session.stop('again'), result);
    console.log('Integration recording:', result.directory, result.status, result.errors.length, 'warnings');
  } finally { if (session) await session.stop('cleanup'); await demo.close(); }
});

test('browser disconnect retains action journal and raw trace', { timeout: 15000 }, async () => {
  const output = fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-close-'));
  const demo = await startDemo();
  let session;
  try {
    session = await startSession({ url: demo.url, output, headless: true, onStatus: () => {} });
    await delay(800);
    await session.flush();
    await session.browser.close();
    const result = await session.stop('closed');
    assert.equal(result.status, 'partial');
    assert(fs.readFileSync(result.summary, 'utf8').includes('partial'));
    assert(fs.readFileSync(result.summary, 'utf8').includes('Browser disconnected'));
    assert(fs.statSync(path.join(result.rawDirectory, 'recording.trace')).size > 0);
    assert(readEvents(session).length > 0);
  } finally { if (session) await session.stop('cleanup'); await demo.close(); }
});

test('stop immediately after click flushes the recorder buffer', { timeout: 15000 }, async () => {
  const output = fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-last-action-'));
  const demo = await startDemo();
  let session;
  try {
    session = await startSession({ url: demo.url, output, headless: true, onStatus: () => {} });
    await delay(1200);
    const cdp = await session.context.newCDPSession(session.page);
    await nativeClick(cdp, '#save');
    const result = await session.stop('immediate');
    assert(result.trace);
    assert(readEvents(session).some(e => e.action?.selector?.includes('Lưu một lần')));
    assert.equal(demo.getWrites(), 1);
  } finally { if (session) await session.stop('cleanup'); await demo.close(); }
});

test('new popup gets its own DOM and console checkpoint without any click inside it', { timeout: 15000 }, async () => {
  const output = path.join(__dirname, '../test-results/popup');
  const demo = await startDemo();
  let session;
  try {
    session = await startSession({ url: demo.url, output, headless: true, onStatus: () => {} });
    await delay(1200);
    const cdp = await session.context.newCDPSession(session.page);
    await nativeClick(cdp, 'a[target]');
    await eventually(() => readEvents(session).some(e => e.type === 'pageOpened'));
    await delay(650); // Recorder's original click is buffered for popup correlation.
    const result = await session.stop('popup regression');
    assert.equal(result.status, 'saved');
    const opened = readEvents(session).find(e => e.type === 'pageOpened');
    assert.equal(opened.page, 'page2');
    assert.equal(opened.action.opener, 'page1');
    const events = traceEvents(result.trace);
    const group = events.find(e => e.type === 'before' && e.title?.includes('New tab page2 from page1'));
    assert(group);
    const checkpoint = events.find(e => e.type === 'before' && e.parentId === group.callId && e.method === 'evaluateExpression');
    assert(checkpoint);
    assert(events.some(e => e.type === 'frame-snapshot' && e.snapshot.callId === checkpoint.callId && e.snapshot.frameUrl.endsWith('/next') && e.snapshot.isMainFrame));
    const log = events.find(e => e.type === 'console' && e.text?.includes('"action":"pageOpened"'));
    assert(log);
    assert(log.text.includes('"page":"page2"'));
    assert(events.some(e => e.type === 'screencast-frame'));
    assert.equal(demo.getWrites(), 0);
    fs.writeFileSync(path.join(__dirname, '../test-results/latest.json'), JSON.stringify(result, null, 2));
  } finally { if (session) await session.stop('cleanup'); await demo.close(); }
});

test('filmstrip can be disabled without losing console notes and DOM', { timeout: 15000 }, async () => {
  const demo = await startDemo();
  const output = fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-no-filmstrip-'));
  let session;
  try {
    session = await startSession({ url: demo.url, output, headless: true, filmstrip: false, onStatus: () => {} });
    await delay(700);
    const result = await session.stop('test');
    const events = traceEvents(result.trace);
    assert.equal(events.filter(e => e.type === 'screencast-frame').length, 0);
    assert(events.some(e => e.type === 'frame-snapshot'));
    assert(events.some(e => e.type === 'console' && e.text?.startsWith('[pwrec] ')));
  } finally { if (session) await session.stop('cleanup'); await demo.close(); }
});

for (const method of ['Enter', 'SIGINT']) test(`CLI demo saves via ${method}`, { timeout: 20000 }, async () => {
  const output = fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-cli-'));
  const child = spawn(process.execPath, ['bin/pwrec.cjs', '--demo', '--headless', '--output', output], { cwd: path.join(__dirname, '..'), stdio: ['pipe', 'pipe', 'pipe'] });
  let stdout = '', stderr = '', sent = false;
  child.stdout.on('data', chunk => {
    stdout += chunk;
    if (!sent && stdout.includes('Ready.')) {
      sent = true;
      setTimeout(() => method === 'Enter' ? child.stdin.write('\n') : child.kill('SIGINT'), 800);
    }
  });
  child.stderr.on('data', chunk => { stderr += chunk; });
  const code = await new Promise((resolve, reject) => { child.on('error', reject); child.on('exit', resolve); });
  assert.equal(code, 0, stdout + stderr);
  const directory = path.join(output, fs.readdirSync(output)[0]);
  assert(fs.statSync(path.join(directory, 'trace.zip')).size > 0);
  const manifest = JSON.parse(fs.readFileSync(path.join(directory, 'session.json')));
  assert.equal(manifest.status, 'saved');
  assert.equal(manifest.channel, 'chrome');
});

test('business steps, notes and merged typing survive stop in trace and Markdown', { timeout: 20000 }, async () => {
  const demo = await startDemo();
  const output = fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-notes-'));
  let session;
  try {
    session = await startSession({ url: demo.url, output, headless: true, onStatus: () => {} });
    await session.setStep('Nhập hồ sơ');
    await session.note('Tên theo giấy tờ; cần xác nhận trước khi lưu.');
    const cdp = await session.context.newCDPSession(session.page);
    await nativeClick(cdp, '#name');
    for (const text of ['A', 'n', 'h']) {
      await cdp.send('Input.insertText', { text });
      await delay(100);
    }
    await eventually(() => readEvents(session).some(e => e.action?.text === 'Anh'));
    // Boundary forces pending typing to be committed under the old step.
    await session.setStep('Kiểm tra');
    await cdp.send('Input.insertText', { text: ' B' });
    await eventually(() => readEvents(session).some(e => e.action?.text === 'Anh B'));
    const result = await session.stop('notes regression');
    assert.equal(result.status, 'saved');
    const records = readEvents(session);
    assert(records.filter(e => e.action?.name === 'fill').length >= 4, 'raw typing retained');
    const events = traceEvents(result.trace);
    const fills = events.filter(e => e.type === 'console' && e.text?.startsWith('[pwrec] ')).map(e => JSON.parse(e.text.slice(8))).filter(e => e.action === 'fill');
    assert.equal(fills.length, 2, 'one fill per named step, flushed on stop');
    assert.equal(fills[0].mergedEvents, 3);
    assert.equal(fills[0].businessStep.title, 'Nhập hồ sơ');
    assert.equal(fills[1].businessStep.title, 'Kiểm tra');
    assert(fills[1].code.includes('Anh B'));
    assert(events.some(e => e.title === 'STEP 1: Nhập hồ sơ'));
    assert(events.some(e => e.title?.startsWith('NOTE: Tên theo giấy tờ')));
    assert(events.some(e => e.title?.includes('[1: Nhập hồ sơ]') && e.title.includes("fill('Anh')")));
    const summary = fs.readFileSync(result.summary, 'utf8');
    assert(summary.includes('## 1. Nhập hồ sơ'));
    assert(summary.includes('## 2. Kiểm tra'));
    assert(summary.includes('Tên theo giấy tờ'));
    assert(summary.includes("fill('Anh B')"));
    assert(summary.includes('Đã gộp 3 event'));
    assert.equal(demo.getWrites(), 0);
    fs.writeFileSync(path.join(__dirname, '../test-results/features-latest.json'), JSON.stringify(result, null, 2));
  } finally { if (session) await session.stop('cleanup'); await demo.close(); }
});

test('typing idle timeout creates checkpoint before stopping', { timeout: 15000 }, async () => {
  const demo = await startDemo();
  let session;
  try {
    session = await startSession({ url: demo.url, output: fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-idle-')), headless: true, onStatus: () => {} });
    const cdp = await session.context.newCDPSession(session.page);
    await nativeClick(cdp, '#name');
    await cdp.send('Input.insertText', { text: 'first' });
    await delay(1200);
    const raw = fs.readFileSync(path.join(session.directory, 'raw/recording.trace'), 'utf8');
    assert(raw.includes("fill('first')"));
    await cdp.send('Input.insertText', { text: ' second' });
    const result = await session.stop();
    const fills = traceEvents(result.trace).filter(e => e.type === 'console' && e.text?.includes('"action":"fill"'));
    assert.equal(fills.length, 2);
  } finally { if (session) await session.stop('cleanup'); await demo.close(); }
});

test('CLI commands annotate without stopping; unknown command does not end session', { timeout: 20000 }, async () => {
  const output = fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-cli-notes-'));
  const child = spawn(process.execPath, ['bin/pwrec.cjs', '--demo', '--headless', '--output', output], { cwd: path.join(__dirname, '..'), stdio: ['pipe', 'pipe', 'pipe'] });
  let stdout = '', stderr = '', sent = false;
  child.stdout.on('data', chunk => {
    stdout += chunk;
    if (!sent && stdout.includes('Ready.')) {
      sent = true;
      child.stdin.end('step Duyệt yêu cầu\nnote Chỉ trưởng nhóm được duyệt\nwrong-command\n\n');
    }
  });
  child.stderr.on('data', chunk => { stderr += chunk; });
  const code = await new Promise((resolve, reject) => { child.on('error', reject); child.on('exit', resolve); });
  assert.equal(code, 0, stdout + stderr);
  assert(stdout.includes('Unknown command'));
  const directory = path.join(output, fs.readdirSync(output)[0]);
  const summary = fs.readFileSync(path.join(directory, 'summary.md'), 'utf8');
  assert(summary.includes('Duyệt yêu cầu'));
  assert(summary.includes('Chỉ trưởng nhóm được duyệt'));
  assert(traceEvents(path.join(directory, 'trace.zip')).some(e => e.title === 'STEP 1: Duyệt yêu cầu'));
});

test('doctor reports valid setup and output errors without recording', { timeout: 20000 }, async () => {
  const { doctor } = require('../src/doctor.cjs');
  const output = fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-doctor-'));
  const logs = [];
  assert.equal(await doctor({ output, log: line => logs.push(line) }), true);
  assert(logs.some(line => line.startsWith('OK Browser (chrome)')));
  assert.deepEqual(fs.readdirSync(output), [], 'probe files cleaned up');
  const file = path.join(output, 'not-a-directory');
  fs.writeFileSync(file, 'test');
  assert.equal(await doctor({ output: file, log: line => logs.push(line) }), false);
  assert(logs.some(line => line.startsWith('FAIL Output directory')));
});


test('doctor remains usable before npm dependencies have been installed', () => {
  const project = fs.mkdtempSync(path.join(os.tmpdir(), 'pwrec-no-deps-'));
  for (const file of ['bin/pwrec.cjs', 'src/doctor.cjs', 'src/demo.cjs']) {
    fs.mkdirSync(path.dirname(path.join(project, file)), { recursive: true });
    fs.copyFileSync(path.join(__dirname, '..', file), path.join(project, file));
  }
  const result = spawnSync(process.execPath, ['bin/pwrec.cjs', 'doctor'], { cwd: project, encoding: 'utf8', timeout: 10000, env: { ...process.env, NODE_PATH: '' } });
  assert.equal(result.status, 1, result.stderr);
  assert(result.stdout.includes('FAIL Playwright: Run npm ci --omit=dev'));
  assert(result.stdout.includes('OK Output directory'));
});
