// Adds controls to the actual Playwright Overlay tools list, retaining every native control.
function installToolbar({ binding }) {
  if (window.top !== window) return;
  if (window[binding + '_installed']) { window[binding + '_installed'](); return; }
  const interval = window.setInterval.bind(window);
  const timeout = window.setTimeout.bind(window);
  let host, root, busy = false;
  window[binding + '_installed'] = mount;
  function mount() {
    const native = window.__pwrecNativeOverlay;
    if (!native || native.element.ownerDocument !== document || !native.element.isConnected) return;
    if (host?.isConnected && host.parentNode === native.tools) return;
    host = document.createElement('span');
    host.setAttribute('data-pwrec-toolbar', '');
    root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>
      :host{all:initial;font:14px system-ui;color:#182b42}*{box-sizing:border-box}
      .bar{display:flex;gap:3px;align-items:center;padding:2px 4px;border-left:1px solid #ccd4df;pointer-events:auto}
      button{font:inherit;padding:4px 6px;border:1px solid #bac6d5;border-radius:6px;background:#f5f8fc;color:#182b42;cursor:pointer}button:disabled{opacity:.5}button:focus-visible,textarea:focus{outline:2px solid #1768d1}
      #status{max-width:210px;font-size:12px}dialog{pointer-events:auto;position:fixed;inset:0;margin:auto;width:min(460px,90vw);padding:22px;border:1px solid #9eafc2;border-radius:12px;background:white;color:#182b42;font:14px system-ui}dialog::backdrop{background:#0005}
      textarea{width:100%;min-height:110px;margin:12px 0;padding:10px;font:16px system-ui;border:1px solid #8999ac;border-radius:6px}.actions{display:flex;justify-content:flex-end;gap:8px}#files[hidden]{display:none}#files{display:block;width:100%;margin-top:10px;font:14px system-ui}#fileinfo{font-size:12px;max-height:110px;overflow:auto;white-space:pre-wrap;overflow-wrap:anywhere;margin-top:8px}h2{font-size:20px;margin:0}#error{color:#b32020;white-space:pre-wrap}
    </style><div class="bar" role="toolbar" aria-label="pwrec"><button id="step">Step</button><button id="note">Note</button><button id="snapshot">Snapshot</button><button id="downloads">Downloads</button><span id="status" role="status">Đang ghi</span></div>
    <dialog aria-labelledby="title"><h2 id="title"></h2><label for="text">Nội dung</label><select id="files" aria-label="File tải về" hidden></select><div id="fileinfo"></div><textarea id="text"></textarea><div id="error" role="alert"></div><div class="actions"><button id="cancel">Hủy</button><button id="save">Lưu</button></div></dialog>`;
    native.tools.appendChild(host);
    native.tools.style.flexWrap = 'wrap';
    native.element.style.maxWidth = 'calc(100vw - 20px)';
    native.element.style.width = 'max-content';
    native.overlay._updateVisualPosition();
    const get = id => root.getElementById(id);
    const dialog = root.querySelector('dialog');
    let kind;
    let downloads = [];
    function showFile() {
      const id = get('files').value;
      for (const file of downloads) if (file.id === id) {
        get('text').value = file.filename;
        get('fileinfo').textContent = `Tên gốc: ${file.suggestedFilename}\nTrạng thái: ${file.status}\n${file.failure || `${file.bytes ?? '—'} byte · SHA-256: ${file.sha256 || '—'}`}`;
      }
    }
    async function open(type) {
      if (busy) return;
      kind = type;
      get('title').textContent = type === 'step' ? 'Tên bước nghiệp vụ' : type === 'downloads' ? 'File tải về — đổi tên lưu' : 'Ghi chú';
      get('files').hidden = type !== 'downloads';
      get('fileinfo').textContent = '';
      get('text').value = '';
      get('error').textContent = '';
      if (type === 'downloads') {
        try {
          const files = await window[binding]({ type: 'downloads', text: '' });
          downloads = files;
          get('files').replaceChildren();
          for (const file of files) {
            const option = document.createElement('option');
            option.value = file.id; option.textContent = `${file.id} · ${file.filename} · ${file.status}`;
            option.dataset.filename = file.filename;
            option.dataset.status = file.status;
            get('files').appendChild(option);
          }
          for (const option of get('files').options) { if (option.dataset.status === 'completed') { option.selected = true; break; } }
          showFile();
          if (!files.length) get('error').textContent = 'Chưa có download trong phiên này.';
        } catch (error) { get('error').textContent = error.message; }
      }
      dialog.showModal();
      get('text').focus();
    }
    get('step').onclick = () => open('step');
    get('downloads').onclick = () => void open('downloads');
    get('files').onchange = showFile;
    get('note').onclick = () => open('note');
    get('cancel').onclick = () => { if (!busy) dialog.close(); };
    dialog.addEventListener('cancel', event => { if (busy) event.preventDefault(); });
    async function send(type, text) {
      if (busy) return;
      busy = true;
      for (const button of root.querySelectorAll('button')) button.disabled = true;
      get('status').textContent = 'Đang lưu…';
      try {
        await window[binding]({ type: type === 'downloads' ? 'renameDownload' : type, text, id: get('files').value });
        if (dialog.open) dialog.close();
        get('status').textContent = type === 'snapshot' ? 'Đã lưu snapshot ✓' : type === 'step' ? `Bước: ${text}` : type === 'downloads' ? 'Đã đổi tên file ✓' : 'Đã lưu ghi chú ✓';
      } catch (error) {
        get('status').textContent = 'Lưu chưa thành công';
        get('error').textContent = error.message;
      } finally {
        busy = false;
        for (const button of root.querySelectorAll('button')) button.disabled = false;
      }
    }
    get('save').onclick = () => {
      const text = get('text').value.trim();
      if (!text) { get('error').textContent = 'Anh nhập nội dung trước khi lưu nhé.'; return; }
      void send(kind, text);
    };
    get('snapshot').onclick = () => void send('snapshot', 'Snapshot thủ công');
    // Do not let website bubble listeners treat toolbar edits as business input.
    for (const name of ['click','dblclick','input','change','keydown','keyup','pointerdown','pointerup']) host.addEventListener(name, event => event.stopPropagation());
  }
  window.addEventListener('pwrec-overlay-ready', mount);
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount, { once: true });
  mount();
  timeout(mount, 0);
  interval(mount, 1000);
}
module.exports = { installToolbar };
