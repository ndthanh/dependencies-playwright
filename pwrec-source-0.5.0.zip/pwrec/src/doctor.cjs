const fs = require('node:fs');
const path = require('node:path');
async function doctor({ channel = 'chrome', output = 'recordings', log = console.log } = {}) {
  let ok = true;
  const check = (pass, name, detail) => { if (!pass) ok = false; log(`${pass ? 'OK' : 'FAIL'} ${name}: ${detail}`); };
  check(Number(process.versions.node.split('.')[0]) >= 20, 'Node.js', process.version);
  let playwright;
  try {
    playwright = require('playwright');
    const version = require('playwright/package.json').version;
    check(version === '1.63.0', 'Playwright', `${version}; expected 1.63.0`);
  } catch { check(false, 'Playwright', 'Run npm ci --omit=dev in the project directory.'); }
  let probe;
  try {
    fs.mkdirSync(path.resolve(output), { recursive: true });
    probe = fs.mkdtempSync(path.join(path.resolve(output), '.pwrec-doctor-'));
    fs.writeFileSync(path.join(probe, 'check'), 'pwrec');
    check(true, 'Output directory', path.resolve(output));
  } catch (error) { check(false, 'Output directory', error.message); }
  finally { if (probe) fs.rmSync(probe, { recursive: true, force: true }); }
  if (playwright) {
    let browser;
    try {
      browser = await playwright.chromium.launch({ channel, headless: true, timeout: 15000 });
      check(true, `Browser (${channel})`, browser.version());
    } catch (error) { check(false, `Browser (${channel})`, `${error.message.split('\n')[0]} — Install the selected browser, or use --channel msedge / chromium.`); }
    finally { if (browser) await browser.close(); }
    log(`${fs.existsSync(playwright.chromium.executablePath()) ? 'OK' : 'INFO'} Trace Viewer Chromium: run pwrec install if the viewer cannot open.`);
  }
  log('Doctor only checks local setup; it does not visit your business website.');
  return ok;
}
module.exports = { doctor };
