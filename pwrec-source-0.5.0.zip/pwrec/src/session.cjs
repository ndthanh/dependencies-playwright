const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { chromium } = require('./playwright-compat.cjs').loadPlaywright();
const { installToolbar } = require('./toolbar.cjs');
const { createDownloads } = require('./downloads.cjs');
const { writeReport } = require('./report.cjs');
const version = require('playwright/package.json').version;

async function startSession({ url, output = 'recordings', channel = 'chrome', headless = false, filmstrip = true, maximize = true, onStatus = console.log, onDisconnected = () => {} }) {
  if (version !== '1.63.0') throw new Error(`Expected Playwright 1.63.0, found ${version}`);
  const name = `${new Date().toISOString().replace(/[:.]/g, '-')}-${crypto.randomBytes(3).toString('hex')}`;
  const directory = path.resolve(output, name);
  const rawDirectory = path.join(directory, 'raw');
  fs.mkdirSync(rawDirectory, { recursive: true });
  const journal = path.join(directory, 'actions.jsonl');
  fs.writeFileSync(journal, '');
  const manifest = { version: 1, toolVersion: require('../package.json').version, playwright: version, filmstrip, maximize, url, startedAt: new Date().toISOString(), status: 'starting', actions: 0, checkpoints: 0, errors: [], directory, rawDirectory };
  const saveManifest = () => {
    const file = path.join(directory, 'session.json');
    fs.writeFileSync(file + '.tmp', JSON.stringify(manifest, null, 2));
    fs.renameSync(file + '.tmp', file);
  };
  const append = entry => fs.appendFileSync(journal, JSON.stringify(entry) + '\n');
  const pageIds = new WeakMap();
  let nextPage = 0;
  const openers = new WeakMap();
  const pageId = page => {
    if (!pageIds.has(page)) pageIds.set(page, `page${++nextPage}`);
    return pageIds.get(page);
  };
  let browser;
  let context;
  let tail = Promise.resolve();
  let accepting = true;
  let stopping;
  const pendingPages = new Set();
  let firstPage = true;
  let businessStep = null;
  let nextBusinessStep = 0;
  let pendingFill;
  let fillTimer;
  const reportEntries = [];
  function flushFill() {
    clearTimeout(fillTimer);
    if (!pendingFill) return;
    const { event, page } = pendingFill;
    pendingFill = null;
    checkpoint(event, page);
  }
  function annotate(type, text) {
    if (!accepting || stopping) throw new Error('Recording is stopping');
    text = text.trim();
    if (!text) throw new Error('A title or note is required');
    flushFill();
    if (type === 'businessStep') businessStep = { id: ++nextBusinessStep, title: text };
    const event = { type, text, businessStep, observedAt: new Date().toISOString() };
    append(event);
    reportEntries.push(event);
    const label = type === 'businessStep' ? `STEP ${businessStep.id}: ${text}` : `NOTE: ${text}`;
    let annotationError;
    tail = tail.then(async () => {
      await context.tracing.group(label);
      await context.tracing.groupEnd();
    }).catch(error => { annotationError = error; warn('annotation', error); });
    onStatus(label);
    return tail.then(() => { if (annotationError) throw annotationError; });
  }
  saveManifest();
  const warn = (stage, error, step) => {
    const entry = { type: 'error', stage, step, message: error.message, at: new Date().toISOString() };
    manifest.errors.push(entry);
    append(entry);
    onStatus(`Warning: ${stage}: ${error.message.split('\n')[0]}`);
  };

  function record(kind, page, action, code, extra = {}) {
    if (!accepting || action.name === 'closePage') return; // Native lifecycle handles close exactly once.
    const event = structuredClone({ type: kind, step: ++manifest.actions, observedAt: new Date().toISOString(), page: pageId(page), url: page.url(), action, businessStep, code: (code || '').trim(), ...extra });
    append(event);
    if (action.name === 'download') downloads.linkSignal(event); // Link to the recorder's exact generated trigger code.
    // Retain metadata even if the tab closes before the checkpoint.
    if (action.name === 'fill') {
      if (pendingFill && (pendingFill.page !== page || pendingFill.event.action.selector !== action.selector || pendingFill.event.businessStep?.id !== businessStep?.id)) flushFill();
      event.mergedEvents = (pendingFill?.event.mergedEvents || 0) + 1;
      pendingFill = { event, page };
      clearTimeout(fillTimer);
      fillTimer = setTimeout(flushFill, 750);
      return;
    }
    flushFill();
    checkpoint(event, page);
  }

  function checkpoint(event, page) {
    const action = event.action;
    reportEntries.push(event);
    // The initial blank tab immediately navigates. Its lifecycle is logged;
    // the navigation event will capture the useful document.
    if (action.name === 'openPage' && event.url === 'about:blank') return;
    const label = `${event.businessStep ? `[${event.businessStep.id}: ${event.businessStep.title}] ` : ''}${event.step}. ${event.page} | ${event.code || `${action.name}: ${action.selector || action.url || ''}`}`;
    onStatus(label);
    tail = tail.then(async () => {
      if (action.name !== 'pageClosed' && !action.download && page.isClosed()) throw new Error('Page closed before DOM checkpoint; action retained in actions.jsonl');
      await context.tracing.group(label);
      try {
        if (action.name === 'pageClosed' || (action.download && page.isClosed())) return; // Closed documents have no DOM to snapshot.
        await page.evaluate(note => {
          console.log('[pwrec] ' + JSON.stringify({
            step: note.step, businessStep: note.businessStep, mergedEvents: note.mergedEvents || 1, page: note.page, action: note.action.name,
            locator: note.action.selector || null, code: note.code,
            observedUrl: note.url, checkpointUrl: location.href,
            opener: note.action.opener || null, download: note.action.download || null,
          }));
          return note;
        }, { ...event, snapshotMeaning: 'DOM at checkpoint time, not guaranteed before/after gesture' });
        manifest.checkpoints++;
      } finally { await context.tracing.groupEnd(); }
    }).catch(error => warn('checkpoint', error, event.step));
  }

  const downloads = createDownloads({ directory, getStep: () => businessStep, onError: error => warn('download', error), emit: (type, item) => {
    const page = downloads.page(item.id);
    record(type, page, { name: type, download: item }, `DOWNLOAD ${item.id} ${type.replace('download', '')}: ${item.filename}`, { businessStep: item.businessStep });
  } });

  async function snapshot(page, text = 'Snapshot thủ công') {
    if (!accepting || stopping || page.isClosed()) throw new Error('Page is closed or recording is stopping');
    const errorsBefore = manifest.errors.length;
    record('manualSnapshot', page, { name: 'manualSnapshot', title: text }, `SNAPSHOT: ${text}`);
    await tail;
    if (manifest.errors.length > errorsBefore) throw new Error('Snapshot failed; see terminal and actions.jsonl');
  }

  try {
    browser = await chromium.launch({ timeout: 30000, headless, channel, args: maximize && !headless ? ['--start-maximized'] : [], tracesDir: rawDirectory, handleSIGINT: false, handleSIGTERM: false, handleSIGHUP: false });
    manifest.browser = browser.version();
    manifest.channel = channel;
    context = await browser.newContext({ viewport: null, acceptDownloads: true });
    const binding = '__pwrec_' + crypto.randomBytes(8).toString('hex');
    await context.exposeBinding(binding, async ({ page, frame }, message) => {
      if (frame !== page.mainFrame()) throw new Error('Toolbar is only available in the top frame');
      if (!message || typeof message.text !== 'string') throw new Error('Invalid toolbar message');
      if (message.type === 'downloads') return downloads.list();
      if (message.type === 'renameDownload') { if (stopping) throw new Error('Recording is stopping'); await downloads.rename(message.id, message.text); await tail; return true; }
      if (message.type === 'step') await annotate('businessStep', message.text);
      else if (message.type === 'note') await annotate('note', message.text);
      else if (message.type === 'snapshot') await snapshot(page, message.text);
      else throw new Error('Unknown toolbar command');
      return true;
    });
    await context.addInitScript(installToolbar, { binding });
    async function ensureToolbar(page) {
      if (page.isClosed() || stopping) return;
      let cdp;
      try {
        cdp = await context.newCDPSession(page);
        const result = await cdp.send('Runtime.evaluate', { expression: `(${installToolbar.toString()})(${JSON.stringify({ binding })})` });
        if (result.exceptionDetails) throw new Error(result.exceptionDetails.exception?.description || result.exceptionDetails.text);
      } finally { if (cdp) await cdp.detach().catch(() => {}); }
    }
    context.on('page', page => {
      pageId(page);
      page.on('download', download => { if (accepting) downloads.start(page, pageId(page), download); });
      page.on('domcontentloaded', () => {
        const task = ensureToolbar(page).catch(error => { if (!page.isClosed() && !stopping) warn('toolbar', error); });
        pendingPages.add(task);
        task.finally(() => pendingPages.delete(task));
      });
      page.on('close', () => {
        if (!accepting || stopping) return;
        record('pageClosed', page, { name: 'pageClosed', opener: openers.get(page) || null }, `Closed page ${pageId(page)}: ${page.url()}`);
      });
      // Leave native dialogs for the person recording instead of auto-dismissing.
      page.on('dialog', dialog => onStatus(`Browser dialog (${dialog.type()}): respond in the browser to continue.`));
      // Recorder popup signals are emitted on the OPENER. Capture the new page
      // separately, even when the user opens it and does nothing inside it.
      if (firstPage) { firstPage = false; return; }
      const task = (async () => {
        const opener = await page.opener();
        openers.set(page, opener ? pageId(opener) : null);
        await page.waitForLoadState('domcontentloaded', { timeout: 5000 }).catch(error => {
          if (!page.isClosed()) warn('new tab readiness', error);
        });
        if (page.isClosed()) {
          if (accepting) append({ type: 'pageClosedBeforeCheckpoint', page: pageId(page), opener: opener ? pageId(opener) : null, at: new Date().toISOString() });
          return;
        }
        await ensureToolbar(page);
        const source = opener ? pageId(opener) : null;
        record('pageOpened', page, { name: 'pageOpened', opener: source, url: page.url() },
          `New tab ${pageId(page)}${source ? ` from ${source}` : ''}: ${page.url()}`);
      })().catch(error => warn('new tab', error));
      pendingPages.add(task);
      task.finally(() => pendingPages.delete(task));
    });
    await context.tracing.start({ name: 'recording', title: `pwrec: ${url}`, snapshots: true, screenshots: filmstrip, live: true });
    await context._enableRecorder({ mode: 'recording', recorderMode: 'api', language: 'javascript', hideToolbar: false }, {
      actionAdded: (page, action, code) => record('actionAdded', page, action, code),
      actionUpdated: (page, action, code) => record('actionUpdated', page, action, code),
      signalAdded: (page, signal, code) => record('signalAdded', page, signal, code),
    });
    const page = await context.newPage();
    pageId(page);
    if (maximize && !headless) {
      let cdp;
      try {
        cdp = await context.newCDPSession(page);
        const { windowId } = await cdp.send('Browser.getWindowForTarget');
        await cdp.send('Browser.setWindowBounds', { windowId, bounds: { windowState: 'maximized' } });
        manifest.windowState = 'maximized';
      } catch (error) { warn('maximize', error); }
      finally { if (cdp) await cdp.detach(); }
    }
    browser.on('disconnected', () => { if (!stopping) onDisconnected(); });
    manifest.status = 'recording';
    saveManifest();
    // Navigation is not retried: even an initial URL can have server-side effects.
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 30000 }).catch(error => warn('initial navigation', error));
    return { browser, context, page, directory, manifest, downloads, flush: () => { flushFill(); return tail; }, setStep: title => annotate('businessStep', title), note: text => annotate('note', text), snapshot: (target = page, text) => snapshot(target, text), stop };
  } catch (error) {
    manifest.status = 'failed';
    warn('startup', error);
    saveManifest();
    if (browser) await browser.close().catch(() => {});
    throw error;
  }

  function stop(reason = 'requested') {
    if (stopping) return stopping;
    stopping = (async () => {
      manifest.stopReason = reason;
      let deadline;
      try {
        if (!browser.isConnected()) throw new Error('Browser disconnected; use the raw trace directory for recovery');
        const trace = await Promise.race([
          (async () => {
            // Disable flushes pending recorder actions before its event sink is removed.
            await context._disableRecorder();
            await Promise.all([...pendingPages]);
            await downloads.finish();
            accepting = false;
            flushFill();
            await tail;
            const file = path.join(directory, 'trace.zip');
            await context.tracing.stop({ path: file });
            return file;
          })(),
          new Promise((_, reject) => { deadline = setTimeout(() => reject(new Error('Save timed out after 15s; retaining raw trace and action log')), 15000); }),
        ]);
        manifest.trace = trace;
        manifest.status = manifest.errors.length ? 'saved-with-warnings' : 'saved';
      } catch (error) {
        accepting = false;
        flushFill();
        warn('save', error);
        manifest.status = 'partial';
      } finally {
        clearTimeout(deadline);
        await browser.close().catch(error => warn('close', error));
        await downloads.drain();
        await tail;
        manifest.downloads = downloads.list();
        manifest.finishedAt = new Date().toISOString();
        try { manifest.summary = writeReport(directory, manifest, reportEntries); } catch (error) { warn('summary', error); }
        saveManifest();
      }
      return manifest;
    })();
    return stopping;
  }
}
module.exports = { startSession };
