const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
function validName(name) {
  return name && name === name.trim() && !/[<>:"/\\|?*\x00-\x1f]/.test(name) && !/[. ]$/.test(name) && !/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(name) && Buffer.byteLength(name) <= 200;
}
function safeName(name) {
  let result = String(name || '').replace(/[<>:"/\\|?*\x00-\x1f]/g, '_').trim().replace(/[. ]+$/, '');
  while (Buffer.byteLength(result) > 180) result = [...result].slice(0, -1).join('');
  return validName(result) ? result : 'download.bin';
}
function createDownloads({ directory, emit, getStep, onError }) {
  const items = new Map(), tasks = new Set(), handles = new Map();
  let ordinal = 0;
  const persist = () => { const file = path.join(directory, 'downloads.json'); fs.writeFileSync(file + '.tmp', JSON.stringify([...items.values()], null, 2)); fs.renameSync(file + '.tmp', file); };
  function event(type, item) { persist(); emit(type, structuredClone(item)); }
  function start(page, pageId, download) {
    const id = String(++ordinal).padStart(3, '0');
    const filename = safeName(download.suggestedFilename());
    const item = { id, page: pageId, pageUrl: page.url(), url: download.url(), suggestedFilename: download.suggestedFilename(), filename, relativePath: `downloads/${id}/${filename}`, status: 'started', startedAt: new Date().toISOString(), businessStep: structuredClone(getStep()), trigger: null };
    items.set(id, item); handles.set(id, { download, page }); event('downloadStarted', item);
    const task = (async () => {
      try {
        const destination = path.join(directory, item.relativePath);
        fs.mkdirSync(path.dirname(destination), { recursive: true });
        await download.saveAs(destination);
        const hash = crypto.createHash('sha256');
        for await (const chunk of fs.createReadStream(destination)) hash.update(chunk);
        item.bytes = fs.statSync(destination).size; item.sha256 = hash.digest('hex');
        item.status = 'completed'; item.finishedAt = new Date().toISOString();
        event('downloadCompleted', item);
      } catch (error) {
        item.status = 'failed'; item.failure = error.message; item.finishedAt = new Date().toISOString();
        fs.rmSync(path.join(directory, item.relativePath), { force: true });
        event('downloadFailed', item);
      }
    })().catch(onError);
    tasks.add(task); task.finally(() => tasks.delete(task));
    return id;
  }
  function linkSignal(signal) {
    const id = String(Number(signal.action.downloadAlias || 0) + 1).padStart(3, '0');
    const item = items.get(id);
    if (!item) return;
    item.trigger = { signalStep: signal.step, alias: signal.action.downloadAlias || '', page: signal.page, code: signal.code };
    event('downloadLinked', item);
  }
  async function rename(id, filename) {
    if (typeof filename !== 'string' || !validName(filename)) throw new Error('Tên file không hợp lệ: chỉ nhập tên file, không nhập đường dẫn; tối đa 200 byte.');
    const item = items.get(id);
    if (!item || item.status !== 'completed') throw new Error('Chỉ đổi tên được file đã tải thành công.');
    if (item.filename === filename) return;
    const oldPath = path.join(directory, item.relativePath);
    const relativePath = `downloads/${id}/${filename}`;
    const destination = path.join(directory, relativePath);
    // Exclusive copy prevents overwriting files the user may have added.
    fs.copyFileSync(oldPath, destination, fs.constants.COPYFILE_EXCL);
    try { fs.unlinkSync(oldPath); } catch (error) { fs.unlinkSync(destination); throw error; }
    item.renames ||= [];
    item.renames.push({ from: item.filename, to: filename, at: new Date().toISOString() });
    item.filename = filename; item.relativePath = relativePath;
    event('downloadRenamed', item);
  }
  async function drain() { await Promise.all([...tasks]); }
  async function finish(timeoutMs = 10000) {
    let timer;
    try {
      const done = await Promise.race([drain().then(() => true), new Promise(r => { timer = setTimeout(() => r(false), timeoutMs); })]);
      if (!done) {
        for (const [id, handle] of handles) if (items.get(id).status === 'started') {
          items.get(id).cancelReason = 'Recording stopped while download was still running';
          await handle.download.cancel().catch(() => {});
        }
        await drain();
      }
    } finally { clearTimeout(timer); }
  }
  return { start, linkSignal, rename, drain, finish, list: () => structuredClone([...items.values()]), page: id => handles.get(id)?.page };
}
module.exports = { createDownloads, safeName };
