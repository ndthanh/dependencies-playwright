// Version-pinned, in-memory repair of Playwright's injected selector code.
// Never replace Array.prototype.find on the business website.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const Module = require('node:module');
let installed = false;
function loadPlaywright() {
  if (installed) return require('playwright');
  const root = path.dirname(require.resolve('playwright-core/package.json'));
  if (require(path.join(root, 'package.json')).version !== '1.63.0') throw new Error('pwrec compatibility patch requires Playwright 1.63.0');
  const filename = path.join(root, 'lib/coreBundle.js');
  if (require.cache[filename]) throw new Error('Load pwrec/session before playwright so the legacy-page compatibility patch can be installed.');
  const original = Module._extensions['.js'];
  Module._extensions['.js'] = (module, file) => {
    if (file !== filename) return original(module, file);
    let bundle = fs.readFileSync(file, 'utf8');
    const pattern = /^    source4 = ('.*');$/m;
    const match = bundle.match(pattern);
    if (!match) throw new Error('Unsupported Playwright injected-source layout');
    let source = vm.runInNewContext(match[1]); // Only a string literal from the pinned local package.
    const receivers = ['tokens', '[...nested.body.parsed.parts].reverse()', 'roles', 'queryInAriaOwned(element, "*")', 'entries', 'selector.parts'];
    for (const receiver of receivers) {
      const from = receiver + '.find(';
      if (source.split(from).length !== 2) throw new Error(`Unsupported Playwright find site: ${receiver}`);
      source = source.replace(from, `__pwrecFind(${receiver}, `);
    }
    if (source.includes('.find(')) throw new Error('Unreviewed Array.find in injected source');
    source = `function __pwrecFind(array, predicate, thisArg) { for (let i = 0, n = array.length; i < n; i++) { const value = array[i]; if (predicate.call(thisArg, value, i, array)) return value; } }\n` + source;
    bundle = bundle.replace(pattern, () => `    source4 = ${JSON.stringify(source)};`);
    const recorderPattern = /^    source6 = ('.*');$/m;
    const recorderMatch = bundle.match(recorderPattern);
    if (!recorderMatch) throw new Error('Unsupported recorder-source layout');
    let recorderSource = vm.runInNewContext(recorderMatch[1]);
    const anchor = '    this._updateVisualPosition();\n    this._refreshListeners();';
    if (recorderSource.split(anchor).length !== 2) throw new Error('Unsupported native toolbar constructor');
    recorderSource = recorderSource.replace(anchor, anchor + '\n    this._recorder.injectedScript.window.__pwrecNativeOverlay = { overlay: this, tools: toolsListElement, element: this._overlayElement };\n    this._recorder.injectedScript.window.dispatchEvent(new this._recorder.injectedScript.window.Event("pwrec-overlay-ready"));');
    bundle = bundle.replace(recorderPattern, () => `    source6 = ${JSON.stringify(recorderSource)};`);
    module._compile(bundle, file);
  };
  try { const playwright = require('playwright'); installed = true; return playwright; }
  finally { Module._extensions['.js'] = original; }
}
module.exports = { loadPlaywright };
