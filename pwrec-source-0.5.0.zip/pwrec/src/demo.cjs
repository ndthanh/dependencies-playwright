const http = require('node:http');

async function startDemo() {
  let writes = 0;
  let downloads = 0;
  const server = http.createServer((req, res) => {
    if (req.url === '/download' || req.url === '/download-fail' || req.url === '/download-slow') {
      downloads++;
      res.writeHead(200, { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': 'attachment; filename="report.csv"', ...(req.url !== '/download' ? { 'Content-Length': '999999' } : {}) });
      if (req.url === '/download') res.end('id,customer,amount\n1,Nguyễn Văn An,2000000\n');
      else {
        res.write('id,customer,amount\n');
        const timer = setTimeout(() => res.destroy(), req.url === '/download-fail' ? 150 : 30000);
        res.on('close', () => clearTimeout(timer));
      }
      return;
    }
    if (req.url === '/save' && req.method === 'POST') {
      writes++;
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ writes }));
      return;
    }
    if (req.url === '/stats') {
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({ writes }));
      return;
    }
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    if (req.url === '/frame') {
      res.end('<button id="inside" onclick="this.textContent=\'Frame clicked\'">Inside frame</button>');
      return;
    }
    if (req.url === '/next') {
      res.end('<h1>Next page</h1><a href="/">Back</a>');
      return;
    }
    res.end(`<!doctype html><html lang="vi"><meta charset="utf-8"><title>pwrec demo</title>
      ${req.url === '/legacy' ? `<script>Array.prototype.find = function(value) { if (typeof value === 'function') throw new Error('T24-like legacy find expects a string'); return 'legacy:' + value; };</script>` : ''}
      <style>body{font:17px system-ui;max-width:760px;margin:50px auto;color:#183044}label{display:block;margin:18px 0}input,select,button{font:inherit;padding:10px}button,a{margin-right:15px}output{display:block;margin:22px 0}iframe{display:block;margin-top:25px;border:1px solid #ccd6df}</style>
      <h1>Thử pwrec</h1><p>Thao tác trên trang này rồi quay lại terminal, nhấn Enter để lưu trace.</p>
      <label>Họ tên <input id="name" aria-label="Họ tên"></label>
      <label>Nhóm <select id="team" aria-label="Nhóm"><option>Finance</option><option>Operations</option></select></label>
      <label><input type="checkbox" id="agree"> Đồng ý</label>
      <button id="save">Lưu một lần</button><button id="remove">Bấm rồi biến mất</button>
      <output id="status">Chưa lưu</output><a href="/next">Trang tiếp theo</a><a href="/next" target="_blank">Mở tab mới</a>
      <button id="popup" onclick="window.open('/next', 'pwrec-popup', 'width=500,height=400')">Mở cửa sổ popup</button>
      <p><a id="download" href="/download">Tải CSV</a><a id="download-fail" href="/download-fail">Thử download lỗi</a></p>
      <p>Thử Step → Note → Snapshot trên thanh codegen. Tải CSV hai lần, rồi dùng Downloads để đổi tên một file.</p>
      <iframe src="/frame" title="Frame demo"></iframe>
      <script>save.onclick=async()=>{document.getElementById('status').textContent='Đang lưu';const r=await fetch('/save',{method:'POST'});const data=await r.json();document.getElementById('status').textContent='Đã lưu '+data.writes+' lần';};remove.onclick=()=>remove.remove();</script></html>`);
  });
  await new Promise((resolve, reject) => { server.once('error', reject); server.listen(0, '127.0.0.1', resolve); });
  return { url: `http://127.0.0.1:${server.address().port}`, getWrites: () => writes, getDownloads: () => downloads, close: () => new Promise(r => server.close(r)) };
}
module.exports = { startDemo };
