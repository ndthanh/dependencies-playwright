# pwrec

CLI khảo sát thao tác người dùng, dùng Playwright **1.63.0**. Mở trình duyệt, thao tác như bình thường, lưu locator và DOM checkpoint để xem lại trong Trace Viewer. Không chạy lại các click đã ghi.

## Chạy ngay

Trên máy đang dựng tool, lệnh `pwrec` đã được đăng ký bằng `npm link`:

```sh
pwrec --demo
pwrec "https://trang-web-can-khao-sat"
```

1. Trình duyệt mở ra. Đăng nhập và thực hiện luồng khảo sát.
2. Quay lại terminal, nhấn **Enter trống** hoặc **Ctrl+C** để lưu. Giữ trình duyệt mở cho đến khi lưu xong.
3. Terminal in đường dẫn trace và lệnh mở, ví dụ:

```sh
pwrec view "recordings/2026-10-01T12-00-00-000Z-abcdef/trace.zip"
```

`--demo` mở trang local với ô nhập liệu, checkbox, nút lưu, iframe, chuyển trang và mở tab mới. Nút lưu chỉ tăng bộ đếm trong bộ nhớ của demo.

## Chạy trên Windows bằng thư mục bin

Cần Node.js 20 trở lên (`node` và `npm` có trong PATH) và Google Chrome đã cài trên máy. Từ bản 0.2.1, ghi khảo sát mặc định dùng Chrome. Giải nén mã nguồn, ví dụ đặt dự án tại `C:\Tools\pwrec`. Cài dependency ngay trong dự án:

```powershell
cd C:\Tools\pwrec
npm ci --omit=dev
```

Launcher tìm JavaScript tương đối từ vị trí của chính file `.cmd` (`%~dp0`), không phụ thuộc thư mục đang đứng trong terminal. Có thể thêm thẳng thư mục `pwrec\windows-bin` vào PATH, hoặc copy **hai file** vào thư mục `bin` nằm cạnh thư mục dự án `pwrec`, theo cấu trúc:

```text
<thư mục bất kỳ>\
  bin\
    pwrec.cmd
    tv.cmd
  pwrec\
    bin\pwrec.cjs
    node_modules\
```

Ví dụ copy vào `C:\Tools\bin` khi dự án ở `C:\Tools\pwrec`:

```powershell
New-Item -ItemType Directory -Force C:\Tools\bin
Copy-Item .\windows-bin\pwrec.cmd, .\windows-bin\tv.cmd C:\Tools\bin\
```

Không cần sửa đường dẫn trong `.cmd` với hai cấu trúc trên. Có thể di chuyển cả bộ sang ổ đĩa/thư mục khác mà vẫn chạy được; chỉ cập nhật PATH. Nếu thư mục bin riêng nằm ở vị trí khác, sửa `PWREC_ENTRY` thành đường dẫn tương đối bắt đầu bằng `%~dp0` tới `pwrec.cjs` và bỏ dòng fallback bên dưới.

Thêm `C:\Tools\bin` vào **User PATH** trong Environment Variables của Windows rồi mở terminal mới. Nếu thư mục bin của anh đã có trong PATH thì không cần thêm. Để thử ngay trong phiên PowerShell hiện tại:

```powershell
$env:Path = "C:\Tools\bin;$env:Path"
pwrec --version
pwrec "https://trang-web-can-khao-sat"
pwrec install # Tải Chromium cho Trace Viewer; chỉ cần làm lần đầu
pwrec view "C:\Survey recordings\session\trace.zip"
tv "C:\Survey recordings\session\trace.zip"
```

`pwrec.cmd` gọi trực tiếp `node` và file JavaScript của dự án, không cần `npm install -g` hay `npm link`. `tv.cmd` gọi `pwrec.cmd view` ở cùng thư mục bin. Cả hai chuyển tiếp tham số và mã thoát của CLI. Launcher không đổi thư mục làm việc: trace mặc định nằm trong `recordings` ở thư mục đang gọi lệnh; dùng `--output "D:\Survey recordings"` để chọn nơi lưu khác.

Ghi khảo sát bằng Chrome không cần tải Chromium. Nếu muốn dùng Edge đã cài:

```powershell
pwrec "https://trang-web-can-khao-sat" --channel msedge
```

`--channel chrome` là mặc định. Muốn ghi bằng Chromium của Playwright, chạy `pwrec install` rồi thêm `--channel chromium`. Lệnh `pwrec view` / `tv` vẫn dùng Trace Viewer của Playwright, tách biệt với channel ghi khảo sát. Tool tạo phiên trình duyệt riêng, không dùng profile cá nhân đang mở. Chưa chạy trực tiếp trên Windows hoặc Edge.

## Cài từ mã nguồn

```sh
cd pwrec
npm ci
npx playwright install chromium
npm test
npm link
pwrec --demo
```

Không cần cài global để chạy:

```sh
node bin/pwrec.cjs "https://trang-web-can-khao-sat"
```

## Thanh công cụ codegen mở rộng (0.5.0)

Giữ nguyên thanh nổi codegen của Playwright, gồm tay kéo, Record, Pick locator và các nút Assert. Các nút **Step / Note / Snapshot / Downloads** được nối vào tools list của chính thanh này. Không tạo thanh thay thế. Thao tác trên phần mở rộng không trở thành click/fill nghiệp vụ. Toolbar tiếp tục có trong tab mới và popup.

- **Step**: mở hộp nhập tên bước, gõ tiếng Việt rồi bấm **Lưu**. Hộp đóng khi lưu thành công; thao tác tiếp theo mang tên bước mới.
- **Note**: nhập ghi chú cho bước hiện tại, bấm **Lưu**. Có nút Hủy và hỗ trợ Escape.
- **Snapshot**: chụp DOM checkpoint của đúng trang/cửa sổ đang bấm. Chờ thông báo **Đã lưu snapshot ✓**, sau đó mới thực hiện thao tác quan trọng. Trong Trace Viewer chọn group `SNAPSHOT` rồi `Evaluate` để xem DOM. Checkpoint này đứng riêng, không tự đổi thành tab Before của click tiếp theo; trang vẫn có thể tự cập nhật sau lúc chụp.

Nút Record gốc chỉ bật/tắt phần ghi thao tác của codegen, không kết thúc và lưu toàn phiên pwrec; dùng Enter trống hoặc Ctrl+C trong terminal để lưu phiên.

Tên bước dùng chung cho phiên ghi, kể cả khi chuyển popup/tab. Thanh được chèn lại sau navigation. Không có toolbar trong iframe con; Snapshot ở trang chính bao gồm nội dung frame mà Playwright chụp được. Các lệnh terminal cũ vẫn dùng được.

Cửa sổ chính mặc định mở maximized (không phải fullscreen). `--no-maximize` giữ kích thước thông thường. Popup giữ kích thước website yêu cầu. Nếu hệ điều hành không cho maximize, tool báo cảnh báo rồi tiếp tục ghi.

## Download và đổi tên file

Khi website tải file, pwrec tự lưu bản sao vào `downloads/<id>/<tên-file>` trong phiên, giữ file sau khi browser đóng. Mỗi download có thư mục riêng nên hai file trùng tên không ghi đè nhau. `downloads.json` ghi URL, page, bước nghiệp vụ lúc bắt đầu, tên gốc, tên lưu, trạng thái, kích thước, SHA-256 và thời gian. Signal codegen được liên kết theo download alias; code chờ download/click được giữ nguyên, không phát lại request.

Bấm **Downloads** trên thanh codegen, chọn file đã tải xong, sửa tên rồi **Lưu**. Tên mới chỉ là tên file, không nhận đường dẫn và không ghi đè file có sẵn. Lịch sử đổi tên được lưu; tên gốc vẫn giữ nguyên. File đang tải hoặc tải lỗi chỉ xem thông tin, không đổi tên được.

Trace có các group `DOWNLOAD … Started/Completed/Failed/Renamed/Linked`; Console và Parameters của Evaluate chứa metadata tương ứng. Nếu page đã đóng thì chỉ ghi marker, không giả lập DOM của trang đã mất. `summary.md` có danh sách file, kết quả, hash, code trigger và gợi ý `download.saveAs(...)` dùng biến download tương ứng. Code này là tài liệu phát triển, không tự chạy lại. File tải về nằm cạnh trace, không nhúng trong trace.zip; khi chuyển phiên sang máy khác hãy copy cả thư mục phiên.

Khi dừng phiên, tool chờ download đang chạy tối đa 10 giây rồi yêu cầu hủy và ghi kết quả; thời hạn lưu toàn phiên vẫn là 15 giây. Download lỗi không đồng nghĩa trace bị lỗi: trace vẫn có thể lưu thành công và báo rõ download thất bại. Không theo dõi việc đổi tên bằng Finder/Explorer hoặc hộp Save As của hệ điều hành.

## Demo nhanh trên máy Mac hiện tại

Lệnh `pwrec` đã trỏ tới mã nguồn này:

```sh
pwrec --version
pwrec --demo --output "$HOME/recordings"
```

1. Trên thanh codegen, bấm Step, nhập `Xuất báo cáo cuối ngày` rồi Lưu.
2. Thử Note và nhập tiếng Việt; điền form của demo.
3. Bấm Snapshot, chờ dấu xác nhận, rồi bấm Lưu một lần trên trang.
4. Bấm Tải CSV hai lần. Bấm Downloads, chọn file và đổi tên thành `Báo cáo cuối ngày.csv`.
5. Bấm Thử download lỗi rồi mở Downloads để xem kết quả.
6. Thử mở popup/tab, thao tác và đóng; các event đều lưu trong phiên.
7. Quay lại terminal, Enter trống để lưu. Chạy lệnh `pwrec view ".../trace.zip"` được in ra, mở `summary.md`, `downloads.json` và thư mục `downloads` cạnh trace.

Demo chỉ dùng server local; nút Lưu tăng bộ đếm trong bộ nhớ. Khi cần chạy từ thư mục mã nguồn mà chưa có pwrec trong PATH, dùng `node bin/pwrec.cjs --demo --output "$HOME/recordings"`.

## Trang legacy và Array.find

Bản 0.4.0 sửa riêng sáu chỗ gọi Array.find trong mã sinh locator được Playwright 1.63.0 chèn vào trang: dùng hàm tìm kiếm nội bộ không phụ thuộc Array.prototype.find của website. Bản vá áp dụng trong bộ nhớ lúc khởi động, không sửa file node_modules và không thay Array.prototype.find của T24. Nếu cấu trúc Playwright không đúng bản đã pin, tool báo lỗi thay vì vá đoán.

Đã thử fixture ghi đè Array.prototype.find theo kiểu nhận chuỗi và ném lỗi khi nhận callback; locator, nhập liệu, toolbar và snapshot vẫn chạy, hàm legacy của trang vẫn giữ nguyên. Đây là mô phỏng xung đột, chưa xác minh trên T24 thực tế; các lỗi JavaScript khác của T24 cần stack trace riêng để chẩn đoán.

## Đóng tab và popup

Cả tab và cửa sổ popup được theo dõi qua lifecycle của page. Mỗi lần đóng trong lúc khảo sát có một marker `Closed page pageN: URL` trong trace, event `pageClosed` trong journal và dòng tương ứng trong summary. Không cố chụp DOM của trang đã đóng. Đóng browser do kết thúc phiên không tạo các marker đóng hàng loạt. Khi đóng quá nhanh trước checkpoint, vẫn giữ thông tin lifecycle và cảnh báo nếu DOM chưa kịp ghi.

## Đặt tên bước trong terminal

Trong terminal đang chạy `pwrec`, gõ lệnh rồi nhấn Enter:

```text
step Nhập hồ sơ
note Tên phải khớp giấy tờ khách hàng
```

Quay lại Chrome và thao tác. Khi chuyển sang nghiệp vụ tiếp theo, quay lại terminal:

```text
step Duyệt yêu cầu
note Chỉ trưởng nhóm được duyệt
```

Tên bước áp dụng cho các event nhận được tiếp theo, không đổi tên các thao tác đã ghi. Trace Viewer có marker `STEP`/`NOTE`; mỗi group thao tác và dòng Console có tên bước tương ứng. `note` gắn với bước hiện tại, hoặc là ghi chú chung nếu chưa đặt bước. Chờ thao tác trước hoàn tất rồi nhập lệnh vì recorder có thể buffer click khoảng 500 ms. Nên đặt tên trước khi bắt đầu một nghiệp vụ.

`help` hiện nhắc lệnh. Lệnh không hợp lệ chỉ báo lỗi, không kết thúc phiên. **Enter trên dòng trống** hoặc **Ctrl+C** mới lưu và dừng. Lệnh nhập ở terminal, không gõ vào form của website. Nếu không muốn chuyển terminal, dùng Step/Note trên thanh pwrec của trang.

## Tóm tắt và gộp nhập liệu

Khi lưu, tool tạo `summary.md` cạnh trace, gồm bước nghiệp vụ, ghi chú, page/URL, selector và code của thao tác. Có cả báo cáo cho phiên `partial`, kèm cảnh báo; DOM thiếu không được coi là đã ghi thành công.

Các event `fill` liên tiếp cùng page, locator và bước được gộp cho checkpoint/Console/Markdown. Khoảng nghỉ 750 ms, chuyển thao tác hoặc đổi bước/ghi chú sẽ chốt nhóm. Dừng phiên cũng chốt phần đang nhập. Gõ tiếp sau khoảng nghỉ tạo checkpoint mới; đây không phải gộp toàn bộ lịch sử của một ô. Không chạy lại fill vào website. `actions.jsonl` giữ nguyên event thô; số event trong journal có thể lớn hơn số checkpoint. DOM là trạng thái lúc checkpoint chạy sau gộp.

## Kiểm tra máy với doctor

```powershell
pwrec doctor
pwrec doctor --channel msedge --output "D:\recordings"
```

Kiểm tra Node.js, phiên bản Playwright, khả năng tạo/ghi thư mục output và khả năng mở browser được chọn. Doctor mở browser headless rồi đóng, không truy cập website nghiệp vụ; có thể tạo thư mục output nếu chưa tồn tại, file thử được xóa sau kiểm tra. Mã thoát 0 khi kiểm tra thành công, 1 khi có lỗi. Không tự cài đặt hay nâng cấp phần mềm. Chromium cho Trace Viewer được báo riêng, không quyết định khả năng ghi bằng Chrome.

## Tham số

```text
pwrec <url>                     URL đầy đủ http:// hoặc https://
pwrec --demo                    Trang thử nghiệm local
--output <directory>            Thư mục cha chứa các phiên, mặc định ./recordings
--channel chrome|msedge|chromium Chọn browser; mặc định Chrome đã cài trên máy
--headless                      Dành cho kiểm thử tự động
--no-maximize                   Không mở maximized cửa sổ chính
--no-filmstrip                  Tắt dải hình screencast của Trace Viewer
pwrec view <path>               Mở trace.zip hoặc thư mục raw
tv <path>                       Lệnh tắt trên Windows khi dùng windows-bin/tv.cmd
pwrec doctor                    Kiểm tra cài đặt; hỗ trợ --channel, --output
pwrec install                   Tải Chromium tương ứng
pwrec --help
pwrec --version
```

Mỗi lần chạy tạo thư mục phiên mới, không ghi đè phiên trước:

```text
recordings/<timestamp-random>/
  trace.zip       Trace hoàn chỉnh khi dừng bằng Enter/Ctrl+C
  actions.jsonl   Thao tác, code/selector, timestamp và lỗi checkpoint
  session.json    Browser, trạng thái phiên và thống kê
  summary.md      Bước nghiệp vụ, ghi chú, thao tác và download
  downloads.json  Metadata download (khi có download)
  downloads/      File thực tế, mỗi download một thư mục ID
  raw/            Trace ghi trực tiếp xuống đĩa
```

Nếu đóng trình duyệt trước khi lưu, tool báo `partial`, giữ raw trace và journal; thử `pwrec view "<session>/raw"`. Đây là phục hồi tốt nhất có thể, không bảo đảm còn toàn bộ event cuối khi browser/process bị đóng đột ngột. Nếu lưu bị treo quá 15 giây, tool giữ dữ liệu raw và thoát với trạng thái partial.

## Xem lại

- Danh sách Actions: group chứa số thứ tự, page và code do recorder sinh, ví dụ `page.getByRole('button', ...).click()`.
- Chọn action `Evaluate` trong group: Call → Parameters / Return value chứa action, selector, code và ghi chú.
- Khung DOM: snapshot của trang lúc checkpoint chạy, có thể inspect trong viewer.
- Dải hình phía trên: screencast được bật mặc định (`screenshots: true` trong tracing). Đây là filmstrip của Trace Viewer, không phải file video MP4 hay lời gọi `page.screenshot()` cho từng bước.
- Tab Console: mỗi checkpoint ghi một dòng `[pwrec]` gồm step, page, action, locator, code, URL và tab gốc nếu có. Log phát trong chính Evaluate của step; chọn step hoặc giới hạn thời gian để lọc.
- Tab mới: có step `New tab page2 from page1` với DOM của tab mới sau DOMContentLoaded, kể cả chưa tương tác. Thao tác mở popup vẫn được giữ trên tab gốc. Recorder có thể buffer click khoảng 500ms nên step tải tab mới có thể xuất hiện trước step click tương ứng.
- Không có click highlight tự động. DOM này không cam kết before/after chính xác của gesture.
- Các lần gõ được gộp theo quy tắc 750 ms ở trên; tên bước nghiệp vụ do người khảo sát đặt qua terminal.

Trace, summary và journal lưu cục bộ, có thể chứa nội dung form, thông tin đăng nhập và dữ liệu trang/network của phiên khảo sát; tool không tự upload chúng.

## Cách ghi

Tool dùng bridge private `_enableRecorder({ recorderMode: 'api' })` của Playwright 1.63.0 để nhận actionAdded/actionUpdated/signalAdded. Các callback đưa metadata vào hàng đợi; sau khi gộp fill, mỗi item mở group rồi gọi `page.evaluate()` để log metadata qua console.log và trả metadata về, đồng thời Playwright tạo DOM checkpoint. Không resolve lại locator và không replay click/fill. Dialog của trang được để người dùng xử lý trực tiếp.

Các action vẫn được ghi vào journal nếu DOM checkpoint gặp lỗi do navigation hoặc tab đóng. Dùng chính xác phiên bản đã pin; thay Playwright cần chạy lại test vì recorder bridge không phải public API.

## Kiểm thử

`npm test` mở fixture local và phát input qua CDP để tách gesture người dùng mô phỏng khỏi API locator.click. Kiểm tra nhập liệu, checkbox, nút biến mất, iframe, popup chưa có tương tác, navigation, số POST, locator trong trace, DOM snapshot, filmstrip bật/tắt, console log nằm trong step, shutdown CLI và phục hồi raw trace. `node scripts/check-viewer.cjs` kiểm tra bản render trong Trace Viewer sau npm test (chỉ có trong gói mã nguồn). Các test bổ sung kiểm tra STEP/NOTE, gộp fill và chốt lúc dừng/đổi bước, summary cho cả phiên partial, lệnh terminal không hợp lệ, doctor với thư mục lỗi và khi thiếu dependency. Chạy thêm `node scripts/check-viewer.cjs --features` để xác minh tên bước, ghi chú, DOM và Console trong Trace Viewer. Test không truy cập hệ thống nghiệp vụ thật.

Các tính năng 0.2.0 chỉ có trong phiên ghi mới. Trace 0.1.0 đã lưu không thể bổ sung hình screencast hoặc DOM tab mới bị thiếu từ quá khứ.

Kiểm thử 0.4.0 bổ sung thao tác toolbar bằng CDP input, tiếng Việt, modal rỗng/Hủy, snapshot trước nút lưu, Array.find legacy, mở/đóng popup và tab, toolbar trong popup và sau navigation. `node scripts/check-viewer.cjs --toolbar` xác minh snapshot thủ công trước lưu trong Trace Viewer. Chưa kiểm thử trực tiếp trên Windows hoặc T24 thật.

Kiểm thử 0.5.0 xác nhận sáu nút codegen gốc còn nguyên, Record tắt/bật hoạt động; tải lặp không replay request; đổi tên tiếng Việt trên modal; chống ghi đè/path traversal; file còn sau đóng browser và SHA-256 đúng; ghi lỗi tải/hủy lúc kết thúc.
