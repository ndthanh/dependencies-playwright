@echo off
rem Use the same project configured in the sibling pwrec.cmd.
call "%~dp0pwrec.cmd" view %*
exit /b %errorlevel%
