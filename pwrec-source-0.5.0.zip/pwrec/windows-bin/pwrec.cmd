@echo off
setlocal
rem Resolve from this launcher, not from the caller's working directory.
rem Layout: pwrec\windows-bin\pwrec.cmd -> pwrec\bin\pwrec.cjs
set "PWREC_ENTRY=%~dp0..\bin\pwrec.cjs"
rem Also support sibling directories: bin\pwrec.cmd and pwrec\bin\pwrec.cjs
if not exist "%PWREC_ENTRY%" set "PWREC_ENTRY=%~dp0..\pwrec\bin\pwrec.cjs"

if not exist "%PWREC_ENTRY%" (
  echo [pwrec] Entry point not found: "%PWREC_ENTRY%" 1>&2
  echo [pwrec] Keep this launcher in pwrec\windows-bin or in a bin folder beside pwrec. 1>&2
  exit /b 1
)

node "%PWREC_ENTRY%" %*
exit /b %errorlevel%
